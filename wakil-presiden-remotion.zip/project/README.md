# Bagaimana jika kamu menggantikan Gibran sebagai Wakil Presiden? (Remotion)

Video storytelling 2D 9:16 (1080×1920, 30 fps, ±58 dtk, tanpa header). Skenario fiktif/hiburan hipotetis,
bukan laporan kejadian nyata. Presiden digambar generik, bukan kemiripan wajah tokoh nyata.

## Status jujur
- Dibuat tanpa akses internet, jadi `npm install`, render MP4, dan pengecekan frame BELUM diuji di sini.
- Logika caption (23 halaman subtitle) dan pembagian beat (total 1740 frame) sudah diuji dengan Node.
- Typecheck hanya longgar (stub React/Remotion). Jalankan `npm run typecheck` setelah `npm install`.
- Jika ada error saat preview, kirimkan pesannya ke Claude untuk diperbaiki.

## Yang perlu Anda ganti
1. `public/narasi.mp3` sekarang adalah **file hening 58 dtk (placeholder)**. Ganti dengan rekaman narasi asli.
2. SFX & musik di `public/sounds/*.wav` adalah sintetis (placeholder). Ganti file dengan nama yang sama untuk hasil lebih baik.
3. Jika narasi asli mulai lebih lambat/cepat dari SRT: ubah **AUDIO_OFFSET** di `src/data/config.ts` (detik).
4. Jika narasi asli lebih panjang dari 58 dtk: ubah `DURATION_SEC` di `src/data/config.ts`.
5. Timing beat ada di `src/data/beats.ts` (diturunkan dari SRT, sementara sampai audio asli ada).

## Struktur
- `captions.srt` : patokan utama subtitle. `src/data/captions.ts` : data + konversi `Math.round(timestamp * fps)`.
- `src/components/` : MainCharacter, CharacterExpressions, tiap adegan, Subtitle, SoundEffects.
- `reference/` : gambar referensi karakter dan storyboard (tidak dipakai sebagai background video).

## Tutorial Windows (pemula)
1. Instal **Node.js LTS** dari nodejs.org (Next, Next, Finish).
2. Klik kanan file ZIP, pilih **Extract All**.
3. Buka folder hasil ekstrak (yang berisi `package.json`).
4. Klik kolom alamat folder, ketik `cmd`, tekan Enter. Terminal terbuka di folder itu.
5. Ketik `npm install`, Enter. Tunggu selesai (butuh internet, beberapa menit).
6. Ketik `npm run dev`, Enter. Browser terbuka otomatis.
7. Di Remotion Studio, pilih komposisi **Main** dan tekan Play untuk preview.
8. Untuk membuat video: tutup preview (Ctrl+C di terminal), ketik `npm run render`, Enter.
9. Hasil ada di folder **out/video.mp4**.

Jika node/npm tidak dikenali, tutup lalu buka ulang terminal setelah instal Node.js.
