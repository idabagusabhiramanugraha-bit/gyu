import React from 'react';

const INK = '#111';

// Warga generik (kepala kulit, bukan putih) agar berbeda dari karakter utama.
export const Citizen: React.FC<{
  shirt?: string; hair?: string; raise?: number; mood?: 'shock' | 'sad' | 'angry' | 'neutral'; walk?: number;
  silhouette?: boolean; poster?: string; posterColor?: string; width?: number; style?: React.CSSProperties;
}> = ({shirt = '#4f86c6', hair = '#222', raise = 0, mood = 'neutral', walk = 0, silhouette = false, poster, posterColor = '#fff', width = 140, style}) => {
  const skin = silhouette ? '#3b404c' : '#f1cba6';
  const body = silhouette ? '#3b404c' : shirt;
  const hr = silhouette ? '#3b404c' : hair;
  const sw = Math.sin(walk) * 14;
  return (
    <svg width={width} height={(width * 300) / 140} viewBox="0 0 140 300" style={{overflow: 'visible', ...style}}>
      <g transform={`rotate(${sw} 55 190)`}><line x1={55} y1={190} x2={55} y2={282} stroke={INK} strokeWidth={9} strokeLinecap="round" /></g>
      <g transform={`rotate(${-sw} 85 190)`}><line x1={85} y1={190} x2={85} y2={282} stroke={INK} strokeWidth={9} strokeLinecap="round" /></g>
      <path d="M38 110 Q70 98 102 110 L108 200 L32 200 Z" fill={body} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <g transform={`rotate(${-raise} 102 118)`}><line x1={102} y1={118} x2={102} y2={190} stroke={INK} strokeWidth={8} strokeLinecap="round" /></g>
      <g transform={`rotate(${raise} 38 118)`}><line x1={38} y1={118} x2={38} y2={190} stroke={INK} strokeWidth={8} strokeLinecap="round" /></g>
      <circle cx={70} cy={68} r={36} fill={skin} stroke={INK} strokeWidth={5} />
      <path d="M34 66 Q36 26 72 28 Q106 28 106 66 Q90 44 70 46 Q48 46 34 66 Z" fill={hr} stroke={INK} strokeWidth={4} />
      {!silhouette && (
        <g>
          <circle cx={56} cy={70} r={4.5} fill={INK} /><circle cx={84} cy={70} r={4.5} fill={INK} />
          {mood === 'shock' && <ellipse cx={70} cy={92} rx={7} ry={10} fill="#7a1f24" stroke={INK} strokeWidth={3} />}
          {mood === 'sad' && <path d="M56 96 Q70 86 84 96" fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />}
          {mood === 'angry' && (
            <g>
              <line x1={46} y1={56} x2={64} y2={64} stroke={INK} strokeWidth={5} strokeLinecap="round" />
              <line x1={94} y1={56} x2={76} y2={64} stroke={INK} strokeWidth={5} strokeLinecap="round" />
              <path d="M56 98 Q70 88 84 98" fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />
            </g>
          )}
          {mood === 'neutral' && <line x1={60} y1={92} x2={80} y2={92} stroke={INK} strokeWidth={4} strokeLinecap="round" />}
        </g>
      )}
      {poster !== undefined && (
        <g transform={`translate(70 ${-30 - raise * 0.3})`}>
          <line x1={0} y1={0} x2={0} y2={130} stroke="#7a5a3a" strokeWidth={7} />
          <rect x={-62} y={-70} width={124} height={80} fill={posterColor} stroke={INK} strokeWidth={5} />
          <text x={0} y={-18} textAnchor="middle" fontSize={poster.length > 2 ? 17 : 52} fontWeight={900} fontFamily="Arial Black, Arial, sans-serif" fill={silhouette ? '#222' : '#c8202b'}>{poster}</text>
        </g>
      )}
    </svg>
  );
};
