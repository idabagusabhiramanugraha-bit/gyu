import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {President} from './President';
import {OfficeBG, Desk} from './OfficeBG';
import {lerp, pop, shake} from '../utils';
import {LAYOUT} from '../data/layout';

const Pump: React.FC<{f: number}> = ({f}) => {
  const sway = Math.sin(f * 0.15) * 6;
  const price = Math.round(lerp(f, [10, 90], [10000, 15500], false) / 100) * 100;
  return (
    <svg width={420} height={600} viewBox="0 0 420 600" style={{overflow: 'visible'}}>
      <rect x={30} y={40} width={250} height={520} rx={24} fill="#d4202c" stroke="#111" strokeWidth={8} />
      <rect x={60} y={80} width={190} height={110} rx={10} fill="#10231a" stroke="#111" strokeWidth={6} />
      <text x={155} y={152} textAnchor="middle" fontSize={34} fontFamily="Arial Black, Arial" fill="#7dff9a">{price.toLocaleString('id-ID')}</text>
      <rect x={60} y={230} width={190} height={150} rx={10} fill="#f2f2f2" stroke="#111" strokeWidth={6} />
      <text x={155} y={320} textAnchor="middle" fontSize={64} fontFamily="Arial Black, Arial" fill="#d4202c">BBM</text>
      <rect x={20} y={540} width={270} height={36} rx={8} fill="#444" stroke="#111" strokeWidth={6} />
      <path d={`M280 200 Q${380 + sway} 260 ${360 + sway} 400 Q${350 + sway} 520 ${330 + sway} 530`} fill="none" stroke="#111" strokeWidth={18} strokeLinecap="round" />
      <path d={`M${320 + sway} 520 L${350 + sway} 520 L${364 + sway} 560 L${312 + sway} 560 Z`} fill="#f2a41f" stroke="#111" strokeWidth={6} />
    </svg>
  );
};

const Graph: React.FC<{f: number; fps: number}> = ({f, fps}) => {
  const p = lerp(f, [14, 80], [0, 1], false);
  const pts: [number, number][] = [[20, 300], [90, 260], [150, 270], [210, 190], [270, 150], [330, 60]];
  const shown = pts.map(([x, y], i) => {
    const t = Math.min(1, Math.max(0, p * (pts.length - 1) - (i - 1)));
    return i === 0 ? [x, y] : [pts[i - 1][0] + (x - pts[i - 1][0]) * t, pts[i - 1][1] + (y - pts[i - 1][1]) * t];
  });
  const coins = Math.floor(lerp(f, [20, 90], [0, 8], false));
  return (
    <svg width={400} height={640} viewBox="0 0 400 640" style={{overflow: 'visible'}}>
      <rect x={0} y={0} width={380} height={360} rx={18} fill="#fff" stroke="#111" strokeWidth={7} />
      {[1, 2, 3].map((i) => <line key={i} x1={20} y1={i * 80 + 20} x2={360} y2={i * 80 + 20} stroke="#ddd" strokeWidth={3} />)}
      <polyline points={shown.map((q) => q.join(',')).join(' ')} fill="none" stroke="#ff3b30" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
      {p > 0.95 && <g transform={`translate(330 60) scale(${pop(f, 80, fps, 8)})`}><path d="M-20 30 L0 -10 L30 20 Z" fill="#ff3b30" stroke="#111" strokeWidth={5} /></g>}
      {Array.from({length: coins}, (_, i) => (
        <g key={i}><ellipse cx={190} cy={600 - i * 26} rx={80} ry={20} fill="#f2c230" stroke="#111" strokeWidth={5} /><rect x={110} y={594 - i * 26 - 6} width={160} height={6} fill="#d9a21a" opacity={0.5} /></g>
      ))}
    </svg>
  );
};

// Beat 06 - kebijakan Presiden: close-up + gelembung, pompa BBM, lalu reaksi karakter.
export const FuelPolicyScene: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t1 = Math.round(dur * 0.34);
  const t2 = Math.round(dur * 0.7);
  const talk = Math.abs(Math.sin(f * 0.6)) * (f < t1 || f >= t2 ? 1 : 0);
  const bubble = pop(f, 22, fps, 11);
  const stamp = pop(f, 46, fps, 7);
  const bx = LAYOUT.fuelBubble;

  if (f >= t1 && f < t2) {
    const lf = f - t1;
    const sh = shake(lf, 0, 8, 12);
    return (
      <AbsoluteFill>
        <Cam scale={lerp(lf, [0, t2 - t1], [1, 1.1], false)} x={sh.x} y={sh.y}>
          <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 40%, #3a1a24 0%, #14080f 80%)'}} />
          <div style={{position: 'absolute', left: 60, top: 220, width: 960, textAlign: 'center', fontFamily: FONT, fontSize: 104, lineHeight: 1.0, color: '#fff', WebkitTextStroke: '5px #111', paintOrder: 'stroke fill', transform: `scale(${pop(lf, 6, fps, 8)}) rotate(-3deg)`}}>
            SUBSIDI BBM<br /><span style={{color: '#ff3b30'}}>DIHAPUS</span>
          </div>
          <div style={{position: 'absolute', left: 90, top: 640, transform: `rotate(-3deg)`}}><Pump f={lf} /></div>
          <div style={{position: 'absolute', left: 560, top: 640}}><Graph f={lf} fps={fps} /></div>
        </Cam>
        <Vignette strength={0.6} color="0,0,0" />
      </AbsoluteFill>
    );
  }

  if (f >= t2) {
    const lf = f - t2;
    const worry = lf > 26;
    return (
      <AbsoluteFill>
        <div style={{position: 'absolute', inset: 0, filter: 'blur(7px)', transform: 'scale(1.06)'}}><OfficeBG frame={f} /></div>
        <AbsoluteFill style={{background: 'rgba(40,20,0,0.35)'}} />
        <Cam scale={lerp(lf, [0, dur - t2], [1, 1.12], false)} origin="50% 40%">
          <div style={{position: 'absolute', left: 190, top: 430}}>
            <MainCharacter outfit="suit" bust width={700} expr={worry ? 'confused' : 'serious'} headTilt={worry ? Math.sin(lf * 0.3) * 2 - 4 : 0} hairSway={Math.sin(lf * 0.3) * 3} />
          </div>
          {worry && <div style={{position: 'absolute', left: 760, top: 470, fontFamily: FONT, fontSize: 130, color: '#fff', WebkitTextStroke: '6px #111', transform: `scale(${pop(lf, 26, fps, 8)})`}}>?</div>}
        </Cam>
        <Vignette strength={0.5} />
      </AbsoluteFill>
    );
  }

  // S1: close-up Presiden + gelembung
  const sh = shake(f, 28, 8, 10);
  return (
    <AbsoluteFill>
      <Cam scale={lerp(f, [0, t1], [1.35, 1.5], false)} origin="72% 45%" x={sh.x} y={sh.y}>
        <OfficeBG frame={f} />
        <div style={{position: 'absolute', left: -110, top: 640}}><MainCharacter bust view="back" width={600} headDy={-Math.max(0, Math.sin(f * 0.2)) * 6} /></div>
        <div style={{position: 'absolute', left: 500, top: 540}}><President width={560} talk={talk} mood="angry" gesture={f * 0.35} pointAt={f > 30} /></div>
        <Desk />
      </Cam>
      <div style={{position: 'absolute', left: bx.x, top: bx.y, width: bx.w, height: bx.h, transform: `scale(${bubble})`, transformOrigin: '70% 100%'}}>
        <div style={{position: 'absolute', inset: 0, background: '#fff', border: '8px solid #111', borderRadius: 60, textAlign: 'center', paddingTop: 22}}>
          <div style={{fontFamily: FONT, fontSize: 44, color: '#111'}}>Mulai besok, seluruh</div>
          <div style={{fontFamily: FONT, fontSize: 92, lineHeight: 1.0, color: '#111'}}>SUBSIDI BBM</div>
          <div style={{fontFamily: FONT, fontSize: 98, lineHeight: 1.0, color: '#d4202c', transform: `scale(${stamp}) rotate(-4deg)`}}>DIHAPUS!</div>
        </div>
        <svg width={120} height={110} style={{position: 'absolute', left: 560, top: bx.h - 6}}><path d="M10 0 L100 0 L40 100 Z" fill="#fff" stroke="#111" strokeWidth={8} strokeLinejoin="round" /><rect x={4} y={-12} width={108} height={16} fill="#fff" /></svg>
      </div>
      <Vignette strength={0.4} color="60,20,0" />
    </AbsoluteFill>
  );
};
