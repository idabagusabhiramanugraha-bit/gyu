import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {lerp, pop, pulse} from '../utils';

const Bubble: React.FC<{x: number; y: number; s: number; children: React.ReactNode}> = ({x, y, s, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 460, height: 380, transform: `scale(${s})`, transformOrigin: '70% 100%'}}>
    <div style={{position: 'absolute', inset: 0, background: '#fff', border: '8px solid #111', borderRadius: 190}} />
    <div style={{position: 'absolute', left: 340, top: 360, width: 40, height: 40, borderRadius: 20, background: '#fff', border: '6px solid #111'}} />
    <div style={{position: 'absolute', left: 390, top: 420, width: 22, height: 22, borderRadius: 11, background: '#fff', border: '5px solid #111'}} />
    <svg width={460} height={380} viewBox="0 0 460 380" style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
  </div>
);

// Beat 07 - dilema: berpikir keras, dua gambaran bergantian.
export const DecisionScene: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const zoom = lerp(f, [0, dur], [1, 1.28], false);
  const q = pop(f, 10, fps, 7);
  const sA = f >= 40 && f < 118 ? pop(f, 40, fps, 10) * lerp(f, [108, 118], [1, 0], false) : 0;
  const sB = f >= 112 ? pop(f, 112, fps, 10) : 0;
  const beat = pulse(f, 22);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#1b1d24 0%,#3a3d46 100%)'}} />
      <Cam scale={zoom} origin="45% 45%">
        <div style={{position: 'absolute', left: 170, top: 440}}>
          <MainCharacter bust chinHand width={680} expr="thinking" look={Math.sin(f * 0.09) * 1.2} headTilt={-4 + Math.sin(f * 0.07) * 2} headDy={Math.sin(f * 0.1) * 4} hairSway={Math.sin(f * 0.12) * 2} />
        </div>
        <div style={{position: 'absolute', left: 690, top: 220, fontFamily: FONT, fontSize: 320, color: '#fff', WebkitTextStroke: '10px #111', paintOrder: 'stroke fill', transform: `scale(${q * (1 + beat * 0.06)}) rotate(10deg)`}}>?</div>
        <div style={{position: 'absolute', left: 60, top: 190, fontFamily: FONT, fontSize: 90, color: '#aab', opacity: 0.5, transform: `scale(${pop(f, 24, fps)}) rotate(-12deg)`}}>?</div>
        <Bubble x={40} y={190} s={sA}>
          <rect x={60} y={250} width={340} height={20} fill="#444" />
          <path d="M70 250 Q230 120 390 250" stroke="#333" strokeWidth={14} fill="none" />
          {[130, 190, 250, 310].map((x) => <line key={x} x1={x} y1={250} x2={x} y2={190 + Math.abs(x - 230) * 0.25} stroke="#333" strokeWidth={6} />)}
          <rect x={290} y={150} width={80} height={100} fill="#7ea0d6" stroke="#111" strokeWidth={5} />
          <ellipse cx={120} cy={90} rx={50} ry={16} fill="#f2c230" stroke="#111" strokeWidth={5} />
          <ellipse cx={120} cy={70} rx={50} ry={16} fill="#f2c230" stroke="#111" strokeWidth={5} />
        </Bubble>
        <Bubble x={560} y={500} s={sB}>
          <path d="M110 150 L350 150 L320 290 L140 290 Z" fill="#c98a4a" stroke="#111" strokeWidth={7} strokeLinejoin="round" />
          <circle cx={170} cy={140} r={34} fill="#d4202c" stroke="#111" strokeWidth={5} /><circle cx={235} cy={128} r={34} fill="#3ea35a" stroke="#111" strokeWidth={5} /><circle cx={300} cy={140} r={34} fill="#f2a41f" stroke="#111" strokeWidth={5} />
          <path d="M370 110 L370 40 M345 66 L370 36 L395 66" stroke="#ff3b30" strokeWidth={14} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          <text x={230} y={350} textAnchor="middle" fontSize={44} fontFamily="Arial Black, Arial" fill="#d4202c">MAHAL</text>
        </Bubble>
      </Cam>
      <AbsoluteFill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 35%, rgba(150,0,0,${0.25 * beat}) 100%)`, pointerEvents: 'none'}} />
      <Vignette strength={0.7} />
    </AbsoluteFill>
  );
};
