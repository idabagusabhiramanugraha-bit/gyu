import React from 'react';

export type Expr =
  | 'shocked' | 'confused' | 'happy' | 'smug' | 'angry' | 'thinking' | 'serious'
  | 'nervous' | 'surprised' | 'determined' | 'sleep';

const INK = '#111';
const MOUTH = '#7a1f24';

const Brow = (x1: number, y1: number, x2: number, y2: number) => (
  <line key={`b${x1}${y1}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={9} strokeLinecap="round" />
);
const Dot = (cx: number, cy: number, r = 8) => <circle key={`d${cx}${cy}`} cx={cx} cy={cy} r={r} fill={INK} />;
const Big = (cx: number, cy: number, r: number, px: number, py: number) => (
  <g key={`g${cx}`}>
    <circle cx={cx} cy={cy} r={r} fill="#fff" stroke={INK} strokeWidth={6} />
    <circle cx={cx + px} cy={cy + py} r={7} fill={INK} />
  </g>
);

export const CharacterExpression: React.FC<{expr: Expr; look?: number}> = ({expr, look = 0}) => {
  const px = look * 8;
  switch (expr) {
    case 'sleep':
      return (
        <g fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round">
          <path d="M136 172 Q160 190 184 172" />
          <path d="M216 172 Q240 190 264 172" />
          <path d="M180 228 Q200 238 220 228" />
        </g>
      );
    case 'smug':
      return (
        <g>
          {Dot(162 + px, 180, 7)}{Dot(242 + px, 180, 7)}
          <line x1={136} y1={170} x2={188} y2={170} stroke={INK} strokeWidth={9} strokeLinecap="round" />
          <line x1={212} y1={170} x2={264} y2={170} stroke={INK} strokeWidth={9} strokeLinecap="round" />
          {Brow(132, 144, 188, 152)}{Brow(268, 134, 214, 150)}
          <path d="M150 220 Q205 258 262 214" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'serious':
      return (
        <g>
          {Dot(160 + px, 176)}{Dot(240 + px, 176)}
          {Brow(130, 138, 186, 156)}{Brow(270, 138, 214, 156)}
          <line x1={166} y1={230} x2={234} y2={230} stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'determined':
      return (
        <g>
          {Dot(160 + px, 176)}{Dot(240 + px, 176)}
          {Brow(128, 134, 188, 156)}{Brow(272, 134, 212, 156)}
          <path d="M160 222 Q200 246 240 222" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'shocked':
      return (
        <g>
          {Big(158, 168, 27, px, 2)}{Big(242, 168, 27, px, 2)}
          {Brow(128, 116, 184, 108)}{Brow(216, 108, 272, 116)}
          <ellipse cx={200} cy={238} rx={17} ry={25} fill={MOUTH} stroke={INK} strokeWidth={6} />
        </g>
      );
    case 'surprised':
      return (
        <g>
          {Big(160, 170, 21, px, 0)}{Big(240, 170, 21, px, 0)}
          {Brow(134, 128, 186, 122)}{Brow(214, 122, 266, 128)}
          <ellipse cx={200} cy={236} rx={12} ry={16} fill={MOUTH} stroke={INK} strokeWidth={6} />
        </g>
      );
    case 'confused':
      return (
        <g>
          {Dot(160 + px, 176)}{Dot(240 + px, 176)}
          {Brow(130, 128, 186, 138)}{Brow(268, 152, 214, 140)}
          <path d="M158 232 Q178 216 200 232 T244 230" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'nervous':
      return (
        <g>
          {Big(160, 172, 19, 4 + px, 4)}{Big(240, 172, 19, 4 + px, 4)}
          {Brow(130, 152, 186, 132)}{Brow(270, 152, 214, 132)}
          <path d="M162 236 Q180 224 200 236 T240 236" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
          <path d="M292 128 Q304 150 292 160 Q280 150 292 128 Z" fill="#7fd0ff" stroke={INK} strokeWidth={4} />
        </g>
      );
    case 'thinking':
      return (
        <g>
          {Dot(166 + px + 6, 170)}{Dot(246 + px + 6, 170)}
          {Brow(130, 126, 186, 138)}{Brow(268, 148, 214, 140)}
          <path d="M172 234 L228 226" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'happy':
      return (
        <g>
          <path d="M134 182 Q160 148 186 182" fill="none" stroke={INK} strokeWidth={8} strokeLinecap="round" />
          <path d="M214 182 Q240 148 266 182" fill="none" stroke={INK} strokeWidth={8} strokeLinecap="round" />
          <path d="M148 214 Q200 220 252 214 Q248 274 200 276 Q152 274 148 214 Z" fill={MOUTH} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M172 258 Q200 240 228 258 Q200 274 172 258 Z" fill="#e8746f" />
        </g>
      );
    case 'angry':
      return (
        <g>
          {Dot(160 + px, 180)}{Dot(240 + px, 180)}
          {Brow(122, 122, 188, 160)}{Brow(278, 122, 212, 160)}
          <path d="M156 244 Q200 214 244 244 L234 272 Q200 282 166 272 Z" fill={MOUTH} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        </g>
      );
  }
};
