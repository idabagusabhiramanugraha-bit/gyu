import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, Flag, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {lerp, pop} from '../utils';

const Tree: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-10} y={0} width={20} height={90} fill="#6b4a2f" stroke="#111" strokeWidth={5} />
    <circle cx={0} cy={-20} r={70} fill="#2f8f4e" stroke="#111" strokeWidth={6} />
    <circle cx={-44} cy={20} r={48} fill="#38a35a" stroke="#111" strokeWidth={6} />
    <circle cx={46} cy={16} r={50} fill="#2a8348" stroke="#111" strokeWidth={6} />
  </g>
);

// Beat 03 - memasuki Istana (wide establishing + tracking, parallax).
export const PalaceScene: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const zoom = lerp(f, [0, dur], [1, 1.14], false);
  const walkPhase = f * 0.33;
  const cx = lerp(f, [0, 70], [-40, 0]);
  const rise = lerp(f, [0, dur], [0, -30], false);
  const sparkle = pop(f, 64, fps, 6);
  const cloud = (i: number) => ((f * (0.4 + i * 0.15) + i * 380) % 1500) - 200;
  const cols = [300, 380, 460, 540, 620, 700, 780];

  return (
    <AbsoluteFill style={{background: '#7ec3f5'}}>
      <Cam scale={zoom} origin="50% 60%">
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#5fb2f2 0%,#cfe9ff 55%,#eaf6ff 100%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          {[0, 1, 2].map((i) => (
            <g key={i} transform={`translate(${cloud(i)} ${260 + i * 150})`} opacity={0.95}>
              <ellipse cx={0} cy={0} rx={130} ry={46} fill="#fff" /><ellipse cx={-70} cy={12} rx={80} ry={36} fill="#fff" /><ellipse cx={80} cy={14} rx={90} ry={38} fill="#fff" />
            </g>
          ))}
          <g transform={`translate(${-cx * 0.3} 0)`}>
            <Tree x={90} y={640} s={1.2} /><Tree x={1000} y={650} s={1.2} />
          </g>
          {/* Istana (layer tengah) */}
          <g transform={`translate(${-cx * 0.15} ${rise * 0.3})`}>
            <rect x={40} y={620} width={1000} height={300} fill="#f2f2ee" stroke="#111" strokeWidth={7} />
            {[90, 180, 790, 880].map((x) => <rect key={x} x={x} y={700} width={60} height={120} rx={8} fill="#8fb0d6" stroke="#111" strokeWidth={5} />)}
            <polygon points="240,560 840,560 540,430" fill="#f7f7f3" stroke="#111" strokeWidth={7} strokeLinejoin="round" />
            <rect x={240} y={560} width={600} height={40} fill="#e6e6df" stroke="#111" strokeWidth={6} />
            {cols.map((x) => <rect key={x} x={x - 20} y={600} width={40} height={320} fill="#fbfbf8" stroke="#111" strokeWidth={5} />)}
            <rect x={470} y={760} width={140} height={160} fill="#7a4a2a" stroke="#111" strokeWidth={6} />
            <rect x={200} y={920} width={680} height={26} fill="#e0e0da" stroke="#111" strokeWidth={5} />
            <rect x={160} y={946} width={760} height={26} fill="#d6d6d0" stroke="#111" strokeWidth={5} />
            <rect x={120} y={972} width={840} height={26} fill="#cbcbc5" stroke="#111" strokeWidth={5} />
            <rect x={538} y={346} width={6} height={90} fill="#111" />
            <g transform="translate(544 346)"><Flag w={70} h={46} frame={f} /></g>
          </g>
          {/* lapisan depan */}
          <rect x={0} y={998} width={1080} height={922} fill="#5cae5e" stroke="#111" strokeWidth={6} />
          <polygon points="470,998 610,998 900,1920 180,1920" fill="#e8dcc0" stroke="#111" strokeWidth={6} />
          <g transform={`translate(${-cx * 0.6} 0)`}>
            <rect x={110} y={560} width={10} height={470} fill="#111" /><g transform="translate(120 560)"><Flag w={110} h={74} frame={f} phase={1} /></g>
            <rect x={960} y={560} width={10} height={470} fill="#111" /><g transform="translate(970 560)"><Flag w={110} h={74} frame={f} phase={3} /></g>
          </g>
        </svg>
        <div style={{position: 'absolute', left: 340 + cx, top: 520 + rise}}>
          <MainCharacter outfit="suit" expr="smug" width={400} walk={walkPhase} headTilt={-4 + Math.sin(f * 0.1) * 1.5} hairSway={Math.sin(f * 0.33) * 5} />
        </div>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
          <g transform={`translate(760 ${580 + rise}) scale(${sparkle}) rotate(${f * 2})`}>
            <path d="M0 -44 L10 -10 L44 0 L10 10 L0 44 L-10 10 L-44 0 L-10 -10 Z" fill="#ffd54a" stroke="#111" strokeWidth={4} />
          </g>
        </svg>
      </Cam>
      <Vignette strength={0.25} />
    </AbsoluteFill>
  );
};
