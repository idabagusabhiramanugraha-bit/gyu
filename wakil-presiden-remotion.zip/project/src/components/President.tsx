import React from 'react';

const INK = '#111';
const SKIN = '#f0c6a0';

// Presiden kartun GENERIK (bukan wajah tokoh nyata). Menghadap kiri-tengah.
export const President: React.FC<{
  width?: number; talk?: number; mood?: 'serious' | 'angry'; gesture?: number; pointAt?: boolean; style?: React.CSSProperties;
}> = ({width = 520, talk = 0, mood = 'serious', gesture = 0, pointAt = false, style}) => {
  const angry = mood === 'angry';
  const gy = Math.sin(gesture) * 14;
  return (
    <svg width={width} height={(width * 640) / 520} viewBox="0 0 520 640" style={{overflow: 'visible', ...style}}>
      {/* badan */}
      <path d="M40 640 L58 410 Q100 346 200 338 L330 338 Q440 348 476 412 L490 640 Z" fill="#1a1b22" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
      <polygon points="222,336 318,336 270,430" fill="#fff" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <path d="M256 360 L284 360 L292 480 L270 510 L248 480 Z" fill="#c8102e" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <path d="M222 340 L196 470 L252 420 Z" fill="#2c2d38" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <path d="M318 340 L344 470 L288 420 Z" fill="#2c2d38" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <rect x={360} y={440} width={26} height={16} fill="#fff" stroke={INK} strokeWidth={3} />
      <rect x={360} y={440} width={26} height={8} fill="#d4202c" />
      {/* leher + kepala */}
      <rect x={236} y={296} width={68} height={56} fill="#e2b88f" stroke={INK} strokeWidth={6} />
      <path d="M150 210 Q150 108 270 104 Q392 108 392 210 Q392 330 270 336 Q150 330 150 210 Z" fill={SKIN} stroke={INK} strokeWidth={8} />
      <ellipse cx={150} cy={228} rx={16} ry={28} fill={SKIN} stroke={INK} strokeWidth={6} />
      {/* rambut hitam rapi */}
      <path d="M148 200 Q138 96 262 82 Q396 84 394 200 Q380 140 330 132 Q250 118 196 140 Q158 156 148 200 Z" fill="#14141a" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
      {/* wajah */}
      <circle cx={220} cy={214} r={9} fill={INK} />
      <circle cx={324} cy={214} r={9} fill={INK} />
      {angry ? (
        <>
          <line x1={186} y1={176} x2={246} y2={200} stroke={INK} strokeWidth={13} strokeLinecap="round" />
          <line x1={360} y1={176} x2={300} y2={200} stroke={INK} strokeWidth={13} strokeLinecap="round" />
        </>
      ) : (
        <>
          <line x1={190} y1={186} x2={246} y2={196} stroke={INK} strokeWidth={13} strokeLinecap="round" />
          <line x1={356} y1={186} x2={300} y2={196} stroke={INK} strokeWidth={13} strokeLinecap="round" />
        </>
      )}
      <path d="M268 222 Q258 256 276 258" fill="none" stroke="#c98f68" strokeWidth={6} strokeLinecap="round" />
      <ellipse cx={272} cy={292} rx={32} ry={5 + talk * 20} fill={talk > 0.05 ? '#7a1f24' : INK} stroke={INK} strokeWidth={5} />
      {/* lengan menjelaskan */}
      <g transform={`translate(0 ${gy})`}>
        <path d="M96 420 Q40 480 36 540 L92 470" fill="none" stroke="#1a1b22" strokeWidth={50} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M96 420 Q40 480 36 540" fill="none" stroke={INK} strokeWidth={4} />
        <circle cx={26} cy={512} r={26} fill={SKIN} stroke={INK} strokeWidth={6} />
        {pointAt && <line x1={26} y1={512} x2={-30} y2={470} stroke={SKIN} strokeWidth={14} strokeLinecap="round" />}
      </g>
    </svg>
  );
};
