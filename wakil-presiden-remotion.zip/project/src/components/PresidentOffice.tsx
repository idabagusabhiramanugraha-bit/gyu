import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Cam, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {President} from './President';
import {OfficeBG, Desk} from './OfficeBG';
import {lerp, shake} from '../utils';

// Beat 04 - dipanggil Presiden: two-shot lalu close-up Presiden.
export const PresidentOffice: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const cut = Math.round(dur * 0.55);
  const close = f >= cut;
  const talk = Math.abs(Math.sin(f * 0.55)) * (f % 40 < 30 ? 1 : 0.2);
  const nod = Math.max(0, Math.sin(f * 0.18)) * 10;
  const sh = shake(f, cut, 8, 14);
  const scale = close ? lerp(f, [cut, dur], [1.55, 1.7], false) : lerp(f, [0, cut], [1, 1.08], false);
  const origin = close ? '78% 48%' : '50% 50%';
  return (
    <AbsoluteFill>
      <Cam scale={scale} origin={origin} x={sh.x} y={sh.y}>
        <OfficeBG frame={f} />
        <div style={{position: 'absolute', left: -110, top: 600, opacity: close ? 0.0 : 1}}>
          <MainCharacter bust view="back" width={600} headDy={nod} hairSway={Math.sin(f * 0.2) * 3} />
        </div>
        <div style={{position: 'absolute', left: 500, top: 520}}>
          <President width={560} talk={talk} gesture={f * 0.3} mood="serious" />
        </div>
        <Desk />
      </Cam>
      <Vignette strength={0.35} color="60,30,0" />
    </AbsoluteFill>
  );
};
