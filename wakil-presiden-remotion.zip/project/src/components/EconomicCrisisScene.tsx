import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, Vignette} from './Common';
import {Citizen} from './Citizen';
import {MainCharacter} from './MainCharacter';
import {lerp, pop} from '../utils';

const Observer: React.FC<{f: number}> = ({f}) => (
  <div style={{position: 'absolute', left: 50, top: 930, transform: `translateY(${Math.sin(f * 0.2) * 4}px)`}}>
    <MainCharacter bust width={330} expr="nervous" look={Math.sin(f * 0.1)} />
  </div>
);

const Market: React.FC<{f: number; fps: number}> = ({f, fps}) => {
  const price = Math.round(lerp(f, [8, 50], [12000, 18500], false) / 100) * 100;
  const arrow = pop(f, 40, fps, 8);
  const colors = ['#d4202c', '#f2a41f', '#3ea35a', '#d4202c', '#f2a41f', '#3ea35a'];
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(#ffd98a,#f4b860)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        {Array.from({length: 8}, (_, i) => <rect key={i} x={i * 135} y={180} width={135} height={150} fill={i % 2 ? '#fff' : '#d4202c'} stroke="#111" strokeWidth={5} />)}
        <rect x={0} y={900} width={1080} height={300} fill="#8a5a36" stroke="#111" strokeWidth={8} />
        {colors.map((c, i) => (
          <g key={i}><circle cx={110 + i * 160} cy={880} r={52} fill={c} stroke="#111" strokeWidth={6} /><circle cx={90 + i * 160} cy={860} r={12} fill="#fff" opacity={0.5} /></g>
        ))}
        <rect x={190} y={380} width={700} height={330} rx={16} fill="#1f3d2d" stroke="#6b4a2f" strokeWidth={16} />
        <text x={540} y={470} textAnchor="middle" fontSize={54} fontFamily="Arial Black, Arial" fill="#fff">BERAS 5 KG</text>
        <line x1={300} y1={560} x2={520} y2={560} stroke="#e66" strokeWidth={8} />
        <text x={540} y={620} textAnchor="middle" fontSize={92} fontFamily="Arial Black, Arial" fill="#ffd54a">Rp {price.toLocaleString('id-ID')}</text>
        <g transform={`translate(840 ${600 - 40 * arrow}) scale(${arrow})`}><path d="M0 40 L0 -40 M-34 -8 L0 -44 L34 -8" stroke="#ff3b30" strokeWidth={16} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>
      </svg>
      <div style={{position: 'absolute', left: 430, top: 660 + Math.sin(f * 0.4) * 6}}><Citizen shirt="#3ea35a" hair="#222" mood="shock" raise={lerp(f, [30, 40], [10, 150])} width={200} /></div>
      <div style={{position: 'absolute', left: 120, top: 740}}><Citizen shirt="#c8553d" hair="#6b3d1f" mood="shock" raise={20 + Math.sin(f * 0.5) * 8} width={170} /></div>
      <div style={{position: 'absolute', left: 780, top: 740}}><Citizen shirt="#7a5cc0" hair="#222" mood="sad" raise={10} width={170} /></div>
      <Observer f={f} />
    </AbsoluteFill>
  );
};

const Queue: React.FC<{f: number}> = ({f}) => {
  const shirts = ['#4f86c6', '#d4a21f', '#c8553d', '#3ea35a', '#7a5cc0'];
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(#9fb6cf,#c8d4e0)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={1000} width={1080} height={920} fill="#6c7380" stroke="#111" strokeWidth={6} />
        <rect x={0} y={1000} width={1080} height={22} fill="#9aa0ab" />
        <rect x={40} y={240} width={460} height={760} fill="#8d97a6" stroke="#111" strokeWidth={6} />
        <rect x={80} y={300} width={380} height={170} fill="#e8f0ff" stroke="#111" strokeWidth={5} />
        <text x={270} y={400} textAnchor="middle" fontSize={64} fontFamily="Arial Black, Arial" fill="#d4202c">HARGA ↑</text>
      </svg>
      {shirts.map((c, i) => (
        <div key={i} style={{position: 'absolute', left: 80 + ((i * 210 - f * 2.2) % 1100), top: 640 + (i % 2) * 18}}>
          <Citizen shirt={c} hair={i % 2 ? '#222' : '#5a3a22'} mood={i % 3 === 0 ? 'angry' : 'sad'} walk={f * 0.2 + i} raise={i === 2 ? 130 : 8} width={190} />
        </div>
      ))}
      {[260, 640, 900].map((x, i) => (
        <div key={x} style={{position: 'absolute', left: x, top: 540 - (f % 30) * 0.3, fontFamily: FONT, fontSize: 90, color: '#d4202c', WebkitTextStroke: '4px #111', transform: `rotate(${(i - 1) * 10}deg) scale(${0.9 + 0.1 * Math.sin(f * 0.4 + i)})`}}>{i === 1 ? '?!' : '!'}</div>
      ))}
      <Observer f={f} />
    </AbsoluteFill>
  );
};

const Protest: React.FC<{f: number}> = ({f}) => {
  const posters = ['HARGA NAIK!', 'RAKYAT RESAH', 'A', 'TURUNKAN HARGA', 'B', 'KAMI LAPAR'];
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(#f59a6b,#f7c98d)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={1000} width={1080} height={920} fill="#59514f" stroke="#111" strokeWidth={6} />
        <rect x={0} y={560} width={1080} height={440} fill="#b3b7c2" stroke="#111" strokeWidth={6} opacity={0.6} />
      </svg>
      {posters.map((p, i) => (
        <div key={i} style={{position: 'absolute', left: 20 + i * 170, top: 520 + (i % 2) * 70 - Math.abs(Math.sin(f * 0.18 + i)) * 24}}>
          <Citizen shirt={['#4f86c6', '#d4a21f', '#c8553d', '#3ea35a', '#7a5cc0', '#d4202c'][i]} hair="#222" mood="angry" raise={150} poster={p} width={190} />
        </div>
      ))}
      <Observer f={f} />
    </AbsoluteFill>
  );
};

// Beat 05 - montase krisis: pasar, antrean, demo damai.
export const EconomicCrisisScene: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = Math.floor(dur / 3);
  const shot = f < t ? 0 : f < 2 * t ? 1 : 2;
  const lf = f - shot * t;
  const zoom = shot === 0 ? lerp(lf, [0, t], [1, 1.12], false) : shot === 1 ? 1.05 : lerp(lf, [0, t], [1, 1.2], false);
  const panX = shot === 1 ? lerp(lf, [0, t], [40, -40], false) : 0;
  const whip = [t, 2 * t].some((s) => f >= s && f < s + 8);
  return (
    <AbsoluteFill>
      <Cam scale={zoom} x={panX} origin="50% 45%">
        {shot === 0 && <Market f={lf} fps={fps} />}
        {shot === 1 && <Queue f={lf} />}
        {shot === 2 && <Protest f={lf} />}
      </Cam>
      {whip && <AbsoluteFill style={{background: 'rgba(255,255,255,0.55)', transform: `translateX(${lerp(f % t, [0, 8], [0, 1080], false)}px)`}} />}
      <Vignette strength={lerp(f, [0, dur], [0.2, 0.7], false)} color="40,0,0" />
    </AbsoluteFill>
  );
};
