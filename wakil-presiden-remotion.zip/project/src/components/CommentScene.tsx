import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, FONT2, Vignette} from './Common';
import {Citizen} from './Citizen';
import {MainCharacter} from './MainCharacter';
import {lerp, pop} from '../utils';

// Beat 09 - penonton menentukan cerita. Berakhir dengan freeze frame.
export const CommentScene: React.FC<{dur: number}> = ({dur}) => {
  const raw = useCurrentFrame();
  const {fps} = useVideoConfig();
  const FREEZE = dur - 20;
  const f = Math.min(raw, FREEZE);

  const turn = lerp(f, [22, 46], [0, 1]);
  const scaleX = turn < 0.5 ? 1 - turn * 2 : (turn - 0.5) * 2;
  const front = turn >= 0.5;
  const step = lerp(f, [50, 80], [1, 1.14]);
  const point = lerp(f, [66, 82], [0, 1]);
  const zoom = lerp(f, [0, FREEZE], [1, 1.1], false);
  const bubble = pop(f, 8, fps, 11);
  const card = pop(f, 96, fps, 10);
  const aVotes = Math.round(lerp(f, [100, FREEZE], [12, 1480], false));
  const bVotes = Math.round(lerp(f, [104, FREEZE], [8, 1390], false));
  const total = Math.max(1, aVotes + bVotes);
  const smile = f > 90;

  const crowd = Array.from({length: 9}, (_, i) => i);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(#58a9f0,#cfe8ff)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: 0.35}}>
        {Array.from({length: 22}, (_, i) => <line key={i} x1={540} y1={700} x2={540 + Math.cos(i * 0.285 + raw * 0.004) * 1600} y2={700 + Math.sin(i * 0.285 + raw * 0.004) * 1600} stroke="#fff" strokeWidth={14} />)}
      </svg>
      <Cam scale={zoom} origin="50% 50%">
        {/* siluet massa dengan poster A / B */}
        {crowd.map((i) => (
          <div key={i} style={{position: 'absolute', left: -30 + i * 125, top: 760 + (i % 3) * 40 - Math.abs(Math.sin(f * 0.15 + i)) * 12}}>
            <Citizen silhouette raise={150} poster={i % 2 ? 'B' : 'A'} posterColor="#e8edf5" width={170} />
          </div>
        ))}
        <div style={{position: 'absolute', left: 270, top: 640, transform: `scale(${step}) scaleX(${scaleX})`, transformOrigin: '50% 100%'}}>
          <MainCharacter bust view={front ? 'front' : 'back'} width={540} expr={smile ? 'smug' : 'determined'}
            pointR={point > 0.1} headTilt={smile ? -4 : 0} hairSway={Math.sin(f * 0.2) * 3} armL={10} />
        </div>
      </Cam>

      {/* gelembung: Tulis A atau B di komentar */}
      <div style={{position: 'absolute', left: 90, top: 150, width: 900, transform: `scale(${bubble})`, transformOrigin: '50% 100%'}}>
        <div style={{background: '#fff', border: '8px solid #111', borderRadius: 44, padding: '24px 30px', textAlign: 'center'}}>
          <div style={{fontFamily: FONT, fontSize: 66, lineHeight: 1.05, color: '#111'}}>Tulis <span style={{color: '#12307a'}}>A</span> atau <span style={{color: '#c8202b'}}>B</span><br />di komentar!</div>
        </div>
      </div>

      {/* UI komentar ilustratif */}
      <div style={{position: 'absolute', left: 100, top: 440, width: 880, transform: `scale(${card})`, transformOrigin: '50% 0'}}>
        <div style={{background: 'rgba(255,255,255,0.96)', border: '7px solid #111', borderRadius: 30, padding: 18}}>
          {[{k: 'A', label: 'TERIMA', v: aVotes, c: '#12307a'}, {k: 'B', label: 'TOLAK', v: bVotes, c: '#c8202b'}].map((r) => (
            <div key={r.k} style={{display: 'flex', alignItems: 'center', gap: 16, margin: '8px 0'}}>
              <div style={{width: 76, height: 76, borderRadius: 38, background: r.c, color: '#fff', fontFamily: FONT, fontSize: 52, textAlign: 'center', lineHeight: '76px', border: '5px solid #111'}}>{r.k}</div>
              <div style={{flex: 1}}>
                <div style={{fontFamily: FONT2, fontWeight: 900, fontSize: 30, color: '#111'}}>{r.label} <span style={{color: '#555'}}>· {r.v.toLocaleString('id-ID')} suara</span></div>
                <div style={{height: 22, background: '#e3e6ee', borderRadius: 11, border: '3px solid #111', overflow: 'hidden'}}><div style={{width: `${(r.v / total) * 100}%`, height: '100%', background: r.c}} /></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* ikon komentar melayang */}
      {[0, 1, 2, 3, 4].map((i) => {
        const t = (f * 1.6 + i * 70) % 360;
        return f > 100 ? <div key={i} style={{position: 'absolute', left: 120 + i * 190, top: 1300 - t, fontFamily: FONT, fontSize: 64, color: i % 2 ? '#c8202b' : '#12307a', WebkitTextStroke: '3px #fff', opacity: Math.max(0, Math.min(1, t / 40, (360 - t) / 60))}}>{i % 2 ? 'B' : 'A'}</div> : null;
      })}
      <Vignette strength={0.2} />
    </AbsoluteFill>
  );
};
