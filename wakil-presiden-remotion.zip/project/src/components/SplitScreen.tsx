import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {lerp, pop, shake} from '../utils';

const B_START = 60; // frame lokal saat "B. Tolak" diucapkan (estimasi dari SRT)

// Beat 08 - dua pilihan: layar terbagi diagonal biru (A) dan merah (B).
export const SplitScreen: React.FC<{dur: number}> = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const inA = lerp(f, [0, 12], [-700, 0]);
  const inB = lerp(f - B_START, [0, 12], [700, 0]);
  const pa = pop(f, 6, fps, 7);
  const pb = pop(f, B_START + 6, fps, 7);
  const shA = shake(f, 0, 8, 14);
  const shB = shake(f, B_START, 8, 14);
  const zoomA = lerp(f, [0, 130], [1, 1.07], false);
  const zoomB = lerp(f - B_START, [0, 70], [1, 1.07], false);
  const nod = Math.max(0, Math.sin(f * 0.22)) * 14;
  const shakeHead = f > B_START + 10 ? Math.sin((f - B_START) * 0.5) * 8 : 0;

  return (
    <AbsoluteFill style={{background: '#111'}}>
      {/* PILIHAN A */}
      <div style={{position: 'absolute', inset: 0, clipPath: 'polygon(0 0, 620px 0, 480px 1920px, 0 1920px)', transform: `translate(${inA + shA.x}px, ${shA.y}px)`}}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#2f6fd6 0%,#9cc3f6 100%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: 0.25}}>
          <rect x={20} y={1000} width={560} height={300} fill="#fff" /><polygon points="80,1000 300,860 520,1000" fill="#fff" />
        </svg>
        <div style={{position: 'absolute', left: 50, top: 190, width: 150, height: 150, borderRadius: 75, background: '#12307a', border: '8px solid #fff', color: '#fff', fontFamily: FONT, fontSize: 110, textAlign: 'center', lineHeight: '136px', transform: `scale(${pa})`}}>A</div>
        <div style={{position: 'absolute', left: 230, top: 200, width: 120, height: 120, borderRadius: 60, background: '#2fb457', border: '8px solid #fff', transform: `scale(${pop(f, 18, fps, 8)})`}}>
          <svg width={104} height={104} viewBox="0 0 100 100"><path d="M24 54 L44 74 L78 30" fill="none" stroke="#fff" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" /></svg>
        </div>
        <div style={{position: 'absolute', left: 40, top: 380, width: 480, fontFamily: FONT, fontSize: 70, lineHeight: 1.0, color: '#fff', WebkitTextStroke: '5px #0d2a66', paintOrder: 'stroke fill', transform: `scale(${pa})`, transformOrigin: '0 50%'}}>
          TERIMA<br />KEBIJAKAN<br />PRESIDEN!
        </div>
        <div style={{position: 'absolute', left: 30, top: 720, transform: `scale(${zoomA})`, transformOrigin: '50% 60%'}}>
          <MainCharacter bust width={470} expr="determined" headDy={nod} headTilt={nod * 0.15} hairSway={Math.sin(f * 0.3) * 3} armL={10} />
        </div>
        <div style={{position: 'absolute', left: 90, top: 1200, width: 190, height: 240, background: '#fff', border: '7px solid #111', borderRadius: 12, transform: `rotate(-6deg) scale(${pop(f, 24, fps, 9)})`}}>
          <div style={{margin: '24px 22px', height: 10, background: '#bbb'}} /><div style={{margin: '14px 22px', height: 10, background: '#bbb'}} />
          <svg width={110} height={90} viewBox="0 0 100 100" style={{marginLeft: 36}}><path d="M20 54 L42 76 L82 26" fill="none" stroke="#2fb457" strokeWidth={16} strokeLinecap="round" strokeLinejoin="round" /></svg>
        </div>
      </div>

      {/* PILIHAN B */}
      <div style={{position: 'absolute', inset: 0, clipPath: 'polygon(620px 0, 1080px 0, 1080px 1920px, 480px 1920px)', transform: `translate(${inB + shB.x}px, ${shB.y}px)`, opacity: f >= B_START - 2 ? 1 : 0}}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#b81822 0%,#ff6b5e 100%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: 0.3}}>
          {Array.from({length: 18}, (_, i) => <line key={i} x1={930} y1={620} x2={930 + Math.cos(i * 0.35) * 1500} y2={620 + Math.sin(i * 0.35) * 1500} stroke="#fff" strokeWidth={10} />)}
        </svg>
        <div style={{position: 'absolute', left: 740, top: 190, width: 150, height: 150, borderRadius: 75, background: '#a3121c', border: '8px solid #fff', color: '#fff', fontFamily: FONT, fontSize: 110, textAlign: 'center', lineHeight: '136px', transform: `scale(${pb})`}}>B</div>
        <div style={{position: 'absolute', left: 910, top: 210, width: 110, height: 110, borderRadius: 55, background: '#111', border: '8px solid #fff', transform: `scale(${pop(f, B_START + 18, fps, 8)})`}}>
          <svg width={94} height={94} viewBox="0 0 100 100"><path d="M26 26 L74 74 M74 26 L26 74" stroke="#fff" strokeWidth={14} strokeLinecap="round" /></svg>
        </div>
        <div style={{position: 'absolute', left: 580, top: 380, width: 460, fontFamily: FONT, fontSize: 60, lineHeight: 1.02, color: '#fff', WebkitTextStroke: '5px #5a0a10', paintOrder: 'stroke fill', textAlign: 'right', transform: `scale(${pb})`, transformOrigin: '100% 50%'}}>
          TOLAK<br />KEBIJAKAN<br />PRESIDEN!
        </div>
        <div style={{position: 'absolute', left: 580, top: 720, transform: `scale(${zoomB})`, transformOrigin: '50% 60%'}}>
          <MainCharacter bust width={470} expr="angry" pointR headTilt={shakeHead} hairSway={shakeHead} armL={10} />
        </div>
      </div>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}><line x1={620} y1={0} x2={480} y2={1920} stroke="#fff" strokeWidth={12} /></svg>
      <Vignette strength={0.35} />
    </AbsoluteFill>
  );
};
