import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, Flag, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {lerp, pop, shake} from '../utils';
import {LAYOUT} from '../data/layout';

const FLASHES = [34, 52, 96, 118, 150];

// Beat 02 - berita pengangkatan di televisi (over-the-shoulder).
export const NewsScene: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tv = LAYOUT.tv;
  const zoom = lerp(f, [0, dur], [1, 1.28], false);
  const bannerIn = pop(f, 18, fps, 12);
  const sh = shake(f, 4, 10, 12);
  const flash = FLASHES.reduce((a, s) => Math.max(a, f >= s && f < s + 5 ? 1 - (f - s) / 5 : 0), 0);
  const headShake = f > 90 ? Math.sin((f - 90) * 0.25) * 4 : 0;
  // match cut: layar TV melebar jadi langit Istana
  const grow = lerp(f, [dur - 14, dur], [0, 1], false);

  return (
    <AbsoluteFill style={{background: '#10121c'}}>
      <Cam scale={zoom} origin="50% 40%" x={sh.x} y={sh.y}>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 35%, #2a3350 0%, #10121c 70%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="scr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#dbe9ff" /><stop offset="1" stopColor="#8aa8dc" /></linearGradient>
            <clipPath id="screenClip"><rect x={tv.x + 40} y={tv.y + 40} width={tv.w - 80} height={tv.h - 80} rx={14} /></clipPath>
          </defs>
          <rect x={tv.x} y={tv.y} width={tv.w} height={tv.h} rx={34} fill="#0d0d12" stroke="#000" strokeWidth={10} />
          <rect x={tv.x + 40} y={tv.y + 40} width={tv.w - 80} height={tv.h - 80} rx={14} fill="url(#scr)" />
          <g clipPath="url(#screenClip)">
            {/* ruang konferensi pers */}
            <rect x={tv.x + 40} y={tv.y + 40} width={tv.w - 80} height={300} fill="#f2f6ff" opacity={0.6} />
            <g transform={`translate(${tv.x + 110} ${tv.y + 90})`}><rect x={-6} y={0} width={10} height={420} fill="#8a6a45" /><g transform="translate(4 0)"><Flag w={150} h={100} frame={f} /></g></g>
            <g transform={`translate(${tv.x + tv.w - 270} ${tv.y + 90})`}><rect x={-6} y={0} width={10} height={420} fill="#8a6a45" /><g transform="translate(4 0)"><Flag w={150} h={100} frame={f} phase={2} /></g></g>
            {/* podium + karakter berjas */}
            <foreignObject x={tv.x + 280} y={tv.y + 70} width={400} height={640}>
              <MainCharacter outfit="suit" bust width={400} expr="serious" hairSway={Math.sin(f * 0.2) * 2} />
            </foreignObject>
            <rect x={tv.x + 300} y={tv.y + 450} width={360} height={150} fill="#6b4a2f" stroke="#111" strokeWidth={6} />
            <rect x={tv.x + 40} y={tv.y + 560} width={tv.w - 80} height={160} fill="#1b2236" opacity={0.7} />
            {/* siluet wartawan */}
            {Array.from({length: 7}, (_, i) => (
              <g key={i}><circle cx={tv.x + 90 + i * 130} cy={tv.y + 590 + (i % 2) * 14} r={34} fill="#10131d" /><rect x={tv.x + 56 + i * 130} y={tv.y + 618 + (i % 2) * 14} width={68} height={90} rx={20} fill="#10131d" /></g>
            ))}
          </g>
          <rect x={tv.x + 40} y={tv.y + 40} width={tv.w - 80} height={tv.h - 80} rx={14} fill="none" stroke="#000" strokeWidth={6} />
        </svg>
        <div style={{position: 'absolute', left: tv.x + 40, top: tv.y + 40, width: tv.w - 80, height: tv.h - 80, background: '#fff', opacity: flash * 0.9, borderRadius: 14}} />

        {/* banner berita */}
        <div style={{position: 'absolute', left: LAYOUT.banner.x, top: LAYOUT.banner.y, width: LAYOUT.banner.w, transform: `translateX(${(1 - bannerIn) * -900}px)`}}>
          <div style={{display: 'inline-block', background: '#d4202c', color: '#fff', fontFamily: FONT, fontSize: 34, padding: '8px 24px', transform: 'skewX(-8deg)'}}>BREAKING NEWS</div>
          <div style={{background: '#fff', border: '5px solid #111', padding: '10px 22px 12px'}}>
            <div style={{fontFamily: FONT, fontSize: 70, color: '#111', lineHeight: 1.05}}>GIBRAN DIGANTIKAN!</div>
            <div style={{fontFamily: FONT, fontSize: 30, color: '#233a7a', marginTop: 4}}>RESMI, NAMA BARU WAKIL PRESIDEN RI</div>
          </div>
        </div>

        {/* karakter dari belakang (over-the-shoulder) */}
        <div style={{position: 'absolute', left: -230, top: 700}}>
          <MainCharacter bust view="back" width={720} headTilt={headShake} hairSway={Math.sin(f * 0.15) * 3} />
        </div>
      </Cam>
      <AbsoluteFill style={{pointerEvents: 'none'}}>
        <div style={{position: 'absolute', left: lerp(grow, [0, 1], [tv.x + 40, 0]), top: lerp(grow, [0, 1], [tv.y + 40, 0]), width: lerp(grow, [0, 1], [tv.w - 80, 1080]), height: lerp(grow, [0, 1], [tv.h - 80, 1920]), background: 'linear-gradient(#7ec3f5,#e6f4ff)', opacity: grow > 0 ? 1 : 0}} />
      </AbsoluteFill>
      <Vignette strength={0.55} />
    </AbsoluteFill>
  );
};
