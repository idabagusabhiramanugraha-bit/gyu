import React from 'react';
import {Flag} from './Common';

const Garuda: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke="#111" strokeWidth={5} strokeLinejoin="round">
    {[0, 1, 2, 3, 4].map((i) => (
      <g key={i}>
        <path d={`M-30 ${-20 + i * 22} Q-120 ${-60 + i * 30} -190 ${-70 + i * 34} Q-130 ${-10 + i * 26} -30 ${10 + i * 22} Z`} fill="#e1b73c" />
        <path d={`M30 ${-20 + i * 22} Q120 ${-60 + i * 30} 190 ${-70 + i * 34} Q130 ${-10 + i * 26} 30 ${10 + i * 22} Z`} fill="#e1b73c" />
      </g>
    ))}
    <ellipse cx={0} cy={30} rx={62} ry={84} fill="#d9a92a" />
    <circle cx={0} cy={-72} r={36} fill="#e1b73c" />
    <path d="M30 -78 L56 -64 L30 -56 Z" fill="#c98a1a" />
    <path d="M-40 -8 L40 -8 L40 70 Q0 112 -40 70 Z" fill="#fff" />
    <path d="M-40 -8 L40 -8 L40 30 L-40 30 Z" fill="#d4202c" />
    <circle cx={0} cy={36} r={9} fill="#111" />
  </g>
);

// Ruang kerja Istana hangat. 'blur' untuk shot reaksi.
export const OfficeBG: React.FC<{frame: number}> = ({frame}) => (
  <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
    <defs>
      <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f7ead0" /><stop offset="1" stopColor="#e6cf9f" /></linearGradient>
    </defs>
    <rect width={1080} height={1920} fill="url(#wall)" />
    {[60, 400, 740].map((x) => <rect key={x} x={x} y={120} width={280} height={900} rx={8} fill="none" stroke="#d1a94a" strokeWidth={8} />)}
    <rect x={0} y={1010} width={1080} height={910} fill="#8a5a36" />
    <rect x={0} y={1010} width={1080} height={16} fill="#5b3a22" />
    <g transform="translate(40 150)"><rect x={0} y={0} width={12} height={900} fill="#5b3a22" stroke="#111" strokeWidth={4} /><g transform="translate(12 0)"><Flag w={150} h={100} frame={frame} /></g></g>
    <g transform="translate(990 150)"><rect x={-12} y={0} width={12} height={900} fill="#5b3a22" stroke="#111" strokeWidth={4} /><g transform="translate(-162 0)"><Flag w={150} h={100} frame={frame} phase={2} /></g></g>
    <Garuda x={540} y={330} s={1.05} />
  </svg>
);

export const Desk: React.FC<{y?: number}> = ({y = 1050}) => (
  <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
    <rect x={-20} y={y} width={1120} height={60} rx={10} fill="#a86b3f" stroke="#111" strokeWidth={8} />
    <rect x={-20} y={y + 60} width={1120} height={420} fill="#7b4a29" stroke="#111" strokeWidth={8} />
    <rect x={640} y={y - 16} width={190} height={26} fill="#fff" stroke="#111" strokeWidth={4} transform={`rotate(-4 700 ${y})`} />
    <rect x={700} y={y - 26} width={190} height={26} fill="#f3f3ee" stroke="#111" strokeWidth={4} transform={`rotate(3 760 ${y})`} />
    <rect x={160} y={y - 12} width={80} height={14} fill="#c8102e" stroke="#111" strokeWidth={3} />
  </svg>
);
