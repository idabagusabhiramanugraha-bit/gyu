import React from 'react';
import {CharacterExpression, Expr} from './CharacterExpressions';

export type {Expr};

const INK = '#111';
const HAIR = '#5A3A22';
const HAIR_HI = '#7b5232';
const HOOD = '#D9DCE3';
const HOOD_SH = '#B9BEC9';
const SUIT = '#1a1b22';

export interface CharacterProps {
  expr?: Expr;
  outfit?: 'hoodie' | 'suit';
  view?: 'front' | 'back';
  width?: number;
  bust?: boolean;       // potong di dada (duduk di tempat tidur / close-up)
  walk?: number;        // fase berjalan (radian)
  armL?: number;        // sudut lengan (derajat, + = menjauh dari badan)
  armR?: number;
  headTilt?: number;
  headDy?: number;
  hairSway?: number;
  look?: number;        // -1..1 arah pandang
  chinHand?: boolean;
  pointR?: boolean;
  style?: React.CSSProperties;
}

const Arm: React.FC<{side: 'L' | 'R'; angle: number; suit: boolean; point?: boolean}> = ({side, angle, suit, point}) => {
  const sx = side === 'L' ? 142 : 258;
  const rot = side === 'L' ? angle : -angle;
  return (
    <g transform={`rotate(${rot} ${sx} 306)`}>
      <line x1={sx} y1={306} x2={sx} y2={452} stroke={INK} strokeWidth={14} strokeLinecap="round" />
      <circle cx={sx} cy={458} r={point ? 15 : 13} fill={INK} />
      {point && <line x1={sx} y1={458} x2={sx} y2={505} stroke={INK} strokeWidth={11} strokeLinecap="round" />}
      <rect x={sx - 16} y={296} width={32} height={suit ? 104 : 54} rx={13} fill={suit ? SUIT : HOOD} stroke={INK} strokeWidth={6} />
    </g>
  );
};

export const MainCharacter: React.FC<CharacterProps> = ({
  expr = 'serious', outfit = 'hoodie', view = 'front', width = 400, bust = false, walk, armL, armR,
  headTilt = 0, headDy = 0, hairSway = 0, look = 0, chinHand = false, pointR = false, style,
}) => {
  const suit = outfit === 'suit';
  const front = view === 'front';
  const vh = bust ? 520 : 780;
  const sw = walk !== undefined ? Math.sin(walk) * 24 : 0;
  const aL = armL ?? (walk !== undefined ? 8 - Math.sin(walk) * 22 : 6);
  const aR = pointR ? 128 : armR ?? (walk !== undefined ? 8 + Math.sin(walk) * 22 : 6);
  const bob = walk !== undefined ? Math.abs(Math.cos(walk)) * -8 : 0;

  const hairFront = 'M105 160 Q100 110 120 95 L98 60 L140 78 L135 30 L175 62 L195 10 L218 58 L252 22 L254 72 L292 55 L280 98 Q302 120 296 160 Q250 120 200 125 Q150 120 105 160 Z';
  const hairBack = 'M100 178 Q96 100 140 80 L120 40 L165 62 L190 8 L215 60 L255 25 L262 75 L300 70 Q312 120 300 178 Q292 238 200 252 Q108 238 100 178 Z';

  return (
    <svg width={width} height={(width * vh) / 400} viewBox={`0 0 400 ${vh}`} style={{overflow: 'visible', ...style}}>
      <g transform={`translate(0 ${bob})`}>
        {!bust && <ellipse cx={200} cy={724} rx={110} ry={14} fill="rgba(0,0,0,0.18)" />}
        {!bust && (
          <>
            <g transform={`rotate(${sw} 172 470)`}>
              <line x1={172} y1={470} x2={172} y2={702} stroke={INK} strokeWidth={14} strokeLinecap="round" />
              <ellipse cx={184} cy={712} rx={30} ry={14} fill={INK} />
            </g>
            <g transform={`rotate(${-sw} 228 470)`}>
              <line x1={228} y1={470} x2={228} y2={702} stroke={INK} strokeWidth={14} strokeLinecap="round" />
              <ellipse cx={240} cy={712} rx={30} ry={14} fill={INK} />
            </g>
          </>
        )}

        {/* torso */}
        {suit ? (
          <>
            <path d="M140 292 Q200 270 260 292 L274 480 Q200 492 126 480 Z" fill={SUIT} stroke={INK} strokeWidth={7} strokeLinejoin="round" />
            {front && (
              <>
                <polygon points="176,284 224,284 200,358" fill="#fff" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <path d="M176 286 L158 392 L192 356 Z" fill="#2c2d38" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <path d="M224 286 L242 392 L208 356 Z" fill="#2c2d38" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <path d="M194 310 L206 310 L213 398 L200 424 L187 398 Z" fill="#c8102e" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <rect x={192} y={300} width={16} height={16} rx={4} fill="#a50d25" stroke={INK} strokeWidth={3} />
                <rect x={228} y={346} width={18} height={11} fill="#fff" stroke={INK} strokeWidth={2.5} />
                <rect x={228} y={346} width={18} height={5.5} fill="#d4202c" />
              </>
            )}
          </>
        ) : (
          <>
            <path d="M140 292 Q200 270 260 292 L274 470 Q200 488 126 470 Z" fill={HOOD} stroke={INK} strokeWidth={7} strokeLinejoin="round" />
            {front ? (
              <>
                <path d="M150 405 Q200 392 250 405 L258 455 Q200 468 142 455 Z" fill={HOOD_SH} opacity={0.55} stroke={INK} strokeWidth={4} />
                <path d="M150 292 Q200 336 250 292 Q200 262 150 292 Z" fill={HOOD_SH} stroke={INK} strokeWidth={6} />
                <path d="M186 308 L183 356" stroke="#fff" strokeWidth={7} strokeLinecap="round" />
                <path d="M214 308 L217 356" stroke="#fff" strokeWidth={7} strokeLinecap="round" />
                <circle cx={183} cy={360} r={5} fill="#fff" stroke={INK} strokeWidth={2} />
                <circle cx={217} cy={360} r={5} fill="#fff" stroke={INK} strokeWidth={2} />
              </>
            ) : (
              <ellipse cx={200} cy={306} rx={66} ry={42} fill={HOOD_SH} stroke={INK} strokeWidth={6} />
            )}
          </>
        )}

        {/* lengan (tangan kanan diganti jika memegang dagu) */}
        <Arm side="L" angle={aL} suit={suit} />
        {!chinHand && <Arm side="R" angle={aR} suit={suit} point={pointR} />}

        {/* kepala */}
        <g transform={`translate(0 ${headDy}) rotate(${headTilt} 200 265)`}>
          <circle cx={200} cy={170} r={100} fill="#fff" stroke={INK} strokeWidth={8} />
          {front ? <ellipse cx={200} cy={236} rx={78} ry={30} fill="#eceef4" opacity={0.7} /> : <ellipse cx={200} cy={246} rx={70} ry={20} fill="#e3e6ee" />}
          {front && <CharacterExpression expr={expr} look={look} />}
          <g transform={`rotate(${hairSway} 200 120)`}>
            <path d={front ? hairFront : hairBack} fill={HAIR} stroke="#2a1a10" strokeWidth={6} strokeLinejoin="round" />
            <path d="M150 70 L168 100 M205 30 L212 78 M250 50 L240 92" stroke={HAIR_HI} strokeWidth={6} strokeLinecap="round" fill="none" />
          </g>
        </g>

        {chinHand && (
          <g>
            <path d="M258 306 L304 392 L238 276" fill="none" stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
            <circle cx={236} cy={270 + headDy} r={16} fill={INK} />
          </g>
        )}
      </g>
    </svg>
  );
};
