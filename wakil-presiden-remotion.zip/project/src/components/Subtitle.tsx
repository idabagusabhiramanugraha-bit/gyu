import React from 'react';
import {useCurrentFrame} from 'remotion';
import {KEYWORDS, PAGES} from '../data/captions';
import {LAYOUT} from '../data/layout';
import {FONT2} from './Common';
import {lerp} from '../utils';

const clean = (w: string) => w.toLowerCase().replace(/[^a-z0-9]/g, '');

export const Subtitle: React.FC = () => {
  const f = useCurrentFrame();
  const page = PAGES.find((p) => f >= p.start && f < p.end);
  if (!page) return null;
  const box = LAYOUT.subtitle;
  const enter = lerp(f, [page.start, page.start + 5], [0, 1]);
  return (
    <div style={{position: 'absolute', left: box.x, top: box.y, width: box.w, display: 'flex', justifyContent: 'center', opacity: enter, transform: `translateY(${(1 - enter) * 16}px)`}}>
      <div style={{background: 'rgba(0,0,0,0.5)', borderRadius: 26, padding: '14px 28px', textAlign: 'center'}}>
        {page.lines.map((line, li) => (
          <div key={li} style={{whiteSpace: 'nowrap', fontFamily: FONT2, fontWeight: 900, fontSize: 56, lineHeight: 1.22}}>
            {line.map((w, wi) => {
              const shown = f >= w.start;
              const key = KEYWORDS.has(clean(w.text));
              return (
                <span key={wi} style={{
                  color: key ? '#FFD500' : '#fff', opacity: shown ? 1 : 0, marginRight: 14, display: 'inline-block',
                  textShadow: '0 3px 0 #000, 0 0 8px rgba(0,0,0,0.8)', WebkitTextStroke: '2px #000', paintOrder: 'stroke fill',
                  transform: `scale(${shown ? lerp(f, [w.start, w.start + 4], [1.18, 1]) : 1})`,
                }}>{w.text}</span>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
