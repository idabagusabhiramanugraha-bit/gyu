import React from 'react';
import {Audio, Sequence, staticFile, interpolate} from 'remotion';
import {BEATS} from '../data/beats';
import {DURATION} from '../data/config';

interface Cue {name: string; beat: number; at: number; vol?: number}

// 'at' = frame relatif terhadap awal beat. Semua file ada di public/sounds (placeholder sintetis, bisa diganti).
const CUES: Cue[] = [
  {name: 'notification', beat: 1, at: 28}, {name: 'pop', beat: 1, at: 56}, {name: 'impact_soft', beat: 1, at: 58},
  {name: 'news_sting', beat: 2, at: 0}, {name: 'impact', beat: 2, at: 4}, {name: 'shutter', beat: 2, at: 34, vol: 0.6},
  {name: 'shutter', beat: 2, at: 96, vol: 0.6}, {name: 'shutter', beat: 2, at: 118, vol: 0.5},
  {name: 'whoosh', beat: 3, at: 0}, {name: 'footsteps', beat: 3, at: 10, vol: 0.55}, {name: 'orch', beat: 3, at: 24, vol: 0.7},
  {name: 'whoosh', beat: 4, at: 0, vol: 0.6}, {name: 'paper', beat: 4, at: 20}, {name: 'impact_soft', beat: 4, at: 74},
  {name: 'market', beat: 5, at: 0, vol: 0.5}, {name: 'whoosh', beat: 5, at: 74, vol: 0.7}, {name: 'crowd', beat: 5, at: 78, vol: 0.5},
  {name: 'whoosh', beat: 5, at: 148, vol: 0.7}, {name: 'tension', beat: 5, at: 20, vol: 0.5},
  {name: 'impact', beat: 6, at: 0}, {name: 'paper', beat: 6, at: 18}, {name: 'impact', beat: 6, at: 46},
  {name: 'whoosh', beat: 6, at: 108}, {name: 'alert', beat: 6, at: 112, vol: 0.5}, {name: 'tension', beat: 6, at: 130, vol: 0.5},
  {name: 'whoosh', beat: 6, at: 238, vol: 0.6},
  {name: 'suspense', beat: 7, at: 0, vol: 0.7}, {name: 'heartbeat', beat: 7, at: 12, vol: 0.8}, {name: 'pop', beat: 7, at: 40, vol: 0.5},
  {name: 'impact', beat: 8, at: 0}, {name: 'whoosh', beat: 8, at: 0}, {name: 'pop', beat: 8, at: 6},
  {name: 'impact', beat: 8, at: 60}, {name: 'whoosh', beat: 8, at: 58}, {name: 'pop', beat: 8, at: 66},
  {name: 'comment_pop', beat: 9, at: 8}, {name: 'notification_pop', beat: 9, at: 96}, {name: 'comment_pop', beat: 9, at: 130},
  {name: 'notification_pop', beat: 9, at: 160},
];

export const SoundEffects: React.FC = () => (
  <>
    {/* Musik sinematik; volume rendah supaya tidak menutupi narasi dan naik menuju pilihan A/B */}
    <Audio
      src={staticFile('sounds/music.wav')}
      volume={(f) => interpolate(f, [0, 60, BEATS[7].from, BEATS[8].from, DURATION], [0.0, 0.16, 0.18, 0.26, 0.2], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
    />
    {CUES.map((c, i) => (
      <Sequence key={i} from={BEATS[c.beat - 1].from + c.at}>
        <Audio src={staticFile(`sounds/${c.name}.wav`)} volume={c.vol ?? 0.8} />
      </Sequence>
    ))}
    <Sequence from={DURATION - 20}><Audio src={staticFile('sounds/final_impact.wav')} volume={0.9} /></Sequence>
  </>
);
