import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Cam, FONT, SpeedLines, Vignette} from './Common';
import {MainCharacter} from './MainCharacter';
import {lerp, pop, shake} from '../utils';

const WAKE = 56;

const PhoneScreen: React.FC<{lit: boolean; news: boolean}> = ({lit, news}) => (
  <div style={{position: 'absolute', inset: 10, borderRadius: 24, overflow: 'hidden', background: lit ? '#eef5ff' : '#0b0d14'}}>
    {lit && (
      <div style={{fontFamily: FONT, textAlign: 'center'}}>
        <div style={{background: '#d4202c', color: '#fff', fontSize: 22, padding: '10px 0'}}>BREAKING NEWS</div>
        {news ? (
          <>
            <div style={{color: '#111', fontSize: 27, lineHeight: 1.15, padding: '26px 12px 0'}}>WAKIL PRESIDEN BARU</div>
            <div style={{color: '#d4202c', fontSize: 40, paddingTop: 14}}>KAMU!</div>
          </>
        ) : (
          <div style={{color: '#111', fontSize: 24, padding: '40px 12px'}}>1 PESAN BARU</div>
        )}
      </div>
    )}
  </div>
);

// Beat 01 - bangun tidur dan melihat berita di ponsel.
export const BedroomScene: React.FC<{dur: number}> = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const awake = f >= WAKE;
  const wake = pop(f, WAKE, fps, 8);
  const sleepBreath = Math.sin(f * 0.14) * 7;
  const headDy = awake ? 52 - 78 * wake : 52 + sleepBreath;
  const zoom = lerp(f, [84, 118], [1, 1.55]);
  const sh = shake(f, WAKE, 14, 14);
  const vib = f > 28 && f < WAKE ? Math.sin(f * 2.2) * 5 : 0;
  const phoneT = lerp(f, [WAKE + 10, WAKE + 28], [0, 1]);
  const phoneX = 760 + (520 - 760) * phoneT;
  const phoneY = 900 + (880 - 900) * phoneT;
  const phoneS = 0.9 + 0.55 * phoneT;
  const glow = f > 28 ? 0.35 + 0.25 * Math.sin(f * 0.5) : 0;
  const marks = pop(f, WAKE + 4, fps, 7);

  return (
    <AbsoluteFill style={{background: '#2a2e4a'}}>
      <Cam scale={zoom} origin="55% 55%" x={sh.x} y={sh.y} rot={sh.r}>
        {/* dinding + jendela + bingkai */}
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#303659 0%,#4b5582 60%,#59639a 100%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="win" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#bcd8ff" /><stop offset="1" stopColor="#ffe9b8" /></linearGradient>
          </defs>
          <polygon points="60,230 380,230 760,1100 120,1100" fill="#fff" opacity={0.07} />
          <rect x={60} y={200} width={330} height={440} rx={14} fill="url(#win)" stroke="#111" strokeWidth={10} />
          <line x1={225} y1={200} x2={225} y2={640} stroke="#111" strokeWidth={8} /><line x1={60} y1={420} x2={390} y2={420} stroke="#111" strokeWidth={8} />
          <rect x={470} y={230} width={170} height={210} fill="#7f87b5" stroke="#111" strokeWidth={8} />
          <circle cx={555} cy={310} r={34} fill="#aab1d6" /><rect x={500} y={350} width={110} height={70} fill="#98a0c8" />
          <rect x={700} y={170} width={200} height={140} fill="#7f87b5" stroke="#111" strokeWidth={8} />
          <rect x={0} y={930} width={1080} height={990} fill="#3b3f66" />
          {/* kepala tempat tidur */}
          <rect x={60} y={560} width={780} height={560} rx={40} fill="#6d4a33" stroke="#111" strokeWidth={8} />
          <rect x={110} y={600} width={680} height={400} rx={60} fill="#e8e9f7" stroke="#111" strokeWidth={7} />
          {/* nakas + lampu */}
          <rect x={800} y={1010} width={260} height={320} fill="#7a5638" stroke="#111" strokeWidth={8} />
          <rect x={800} y={1010} width={260} height={26} fill="#946a47" />
          <rect x={915} y={820} width={14} height={190} fill="#222" /><ellipse cx={922} cy={1008} rx={50} ry={12} fill="#222" />
          <polygon points="860,830 984,830 1010,720 834,720" fill="#ffd77a" stroke="#111" strokeWidth={7} />
          <ellipse cx={922} cy={800} rx={190} ry={170} fill="#ffd77a" opacity={0.18} />
        </svg>

        {/* karakter (bust, duduk di kasur) */}
        <div style={{position: 'absolute', left: 220, top: 540}}>
          <MainCharacter bust width={640} expr={awake ? 'shocked' : 'sleep'} headTilt={awake ? -5 * wake : 14} headDy={headDy}
            hairSway={awake ? Math.sin(f * 0.9) * 4 * (1 - Math.min(1, (f - WAKE) / 20)) : 0} look={awake ? -0.4 : 0} />
        </div>

        {/* selimut menutupi badan bawah */}
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <path d="M0 1180 Q260 1110 540 1160 Q820 1210 1080 1130 L1080 1920 L0 1920 Z" fill="#5b5fb0" stroke="#111" strokeWidth={8} />
          <path d="M120 1260 Q300 1230 470 1280 M600 1330 Q800 1290 980 1340 M80 1450 Q300 1420 520 1470" stroke="#454a95" strokeWidth={9} fill="none" strokeLinecap="round" />
        </svg>

        {/* Zzz */}
        {!awake && ['Z', 'Z', 'Z'].map((z, i) => (
          <div key={i} style={{position: 'absolute', left: 700 + i * 50, top: 520 - i * 70 - ((f * 1.2 + i * 20) % 60), fontFamily: FONT, fontSize: 60 + i * 18, color: '#fff', opacity: 0.8, WebkitTextStroke: '3px #111'}}>{z}</div>
        ))}

        {/* ponsel */}
        {glow > 0 && !awake && <div style={{position: 'absolute', left: 700, top: 840, width: 300, height: 400, borderRadius: 60, background: '#7fb7ff', opacity: glow, filter: 'blur(40px)'}} />}
        <div style={{position: 'absolute', left: phoneX, top: phoneY - (awake ? 0 : 0), width: 200, height: 340, background: '#0a0a0e', border: '5px solid #1b1b22', borderRadius: 34, transform: `translate(${vib}px,0) scale(${phoneS}) rotate(${awake ? -6 * phoneT : 0}deg)`, boxShadow: awake ? '0 0 60px rgba(127,183,255,0.8)' : 'none'}}>
          <PhoneScreen lit={f > 28} news={awake} />
        </div>
        {awake && phoneT > 0.6 && (
          <>
            <div style={{position: 'absolute', left: phoneX - 22, top: phoneY + 250, width: 56, height: 36, borderRadius: 20, background: '#111'}} />
            <div style={{position: 'absolute', left: phoneX + 190, top: phoneY + 250, width: 56, height: 36, borderRadius: 20, background: '#111'}} />
          </>
        )}

        {/* tanda seru */}
        {awake && (
          <div style={{position: 'absolute', left: 250, top: 480, fontFamily: FONT, fontSize: 150, color: '#e0262d', WebkitTextStroke: '6px #111', transform: `scale(${marks}) rotate(-12deg)`}}>!!</div>
        )}
      </Cam>
      <SpeedLines opacity={lerp(f, [WAKE, WAKE + 6], [0, 0.6]) * lerp(f, [WAKE + 6, WAKE + 24], [1, 0])} frame={f} cx={540} cy={820} />
      <Vignette strength={0.45} />
    </AbsoluteFill>
  );
};
