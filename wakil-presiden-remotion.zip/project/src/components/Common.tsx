import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {lerp} from '../utils';

export const FONT = "'Arial Black','Segoe UI Black','Helvetica Neue',Arial,sans-serif";
export const FONT2 = "'Segoe UI','Helvetica Neue',Arial,sans-serif";

export const Cam: React.FC<{
  scale?: number; x?: number; y?: number; rot?: number; origin?: string; children?: React.ReactNode;
}> = ({scale = 1, x = 0, y = 0, rot = 0, origin = '50% 50%', children}) => (
  <AbsoluteFill style={{transform: `translate(${x}px, ${y}px) scale(${scale}) rotate(${rot}deg)`, transformOrigin: origin}}>
    {children}
  </AbsoluteFill>
);

export const Vignette: React.FC<{strength?: number; color?: string}> = ({strength = 0.5, color = '0,0,0'}) => (
  <AbsoluteFill
    style={{background: `radial-gradient(ellipse at center, rgba(${color},0) 42%, rgba(${color},${strength}) 100%)`, pointerEvents: 'none'}}
  />
);

export const SpeedLines: React.FC<{opacity: number; frame: number; cx?: number; cy?: number}> = ({opacity, frame, cx = 540, cy = 900}) => {
  if (opacity <= 0.01) return null;
  const lines = Array.from({length: 28}, (_, i) => {
    const a = (i / 28) * Math.PI * 2 + (frame % 3) * 0.02;
    const r1 = 430 + ((i * 53) % 120);
    const r2 = 1500;
    return (
      <line key={i} x1={cx + Math.cos(a) * r1} y1={cy + Math.sin(a) * r1} x2={cx + Math.cos(a) * r2} y2={cy + Math.sin(a) * r2}
        stroke="#fff" strokeWidth={3 + (i % 4) * 2} opacity={0.55} />
    );
  });
  return (
    <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity, pointerEvents: 'none'}}>{lines}</svg>
  );
};

// Bendera Merah Putih berkibar (deterministik).
export const Flag: React.FC<{w: number; h: number; frame: number; phase?: number}> = ({w, h, frame, phase = 0}) => {
  const N = 14;
  const off = (i: number) => Math.sin(frame * 0.22 + i * 0.7 + phase) * 9 * (i / N);
  const top: string[] = [], mid: string[] = [], bot: string[] = [];
  for (let i = 0; i <= N; i++) {
    const x = (i * w) / N, o = off(i);
    top.push(`${x},${o}`); mid.push(`${x},${h / 2 + o}`); bot.push(`${x},${h + o}`);
  }
  const red = `M${top.join(' L')} L${[...mid].reverse().join(' L')} Z`;
  const white = `M${mid.join(' L')} L${[...bot].reverse().join(' L')} Z`;
  return (
    <g>
      <path d={red} fill="#d4202c" stroke="#111" strokeWidth={4} strokeLinejoin="round" />
      <path d={white} fill="#fff" stroke="#111" strokeWidth={4} strokeLinejoin="round" />
    </g>
  );
};

// Overlay transisi di awal beat.
export const Transition: React.FC<{kind: 'flash' | 'dark' | 'whip' | 'none'}> = ({kind}) => {
  const f = useCurrentFrame();
  if (kind === 'none') return null;
  if (kind === 'flash') return <AbsoluteFill style={{background: '#fff', opacity: lerp(f, [0, 9], [0.95, 0], false), pointerEvents: 'none'}} />;
  if (kind === 'dark') return <AbsoluteFill style={{background: '#000', opacity: lerp(f, [0, 6], [1, 0], false), pointerEvents: 'none'}} />;
  const x = lerp(f, [0, 10], [0, -1500], false);
  const streaks = Array.from({length: 18}, (_, i) => (
    <rect key={i} x={0} y={i * 107 + (i % 3) * 13} width={1700 - (i % 4) * 150} height={6 + (i % 5) * 4} fill="#fff" opacity={0.7} />
  ));
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: f > 11 ? 0 : 1}}>
      <svg width={1080} height={1920} style={{transform: `translateX(${x + 1100}px)`}}>
        <rect x={-300} y={0} width={1700} height={1920} fill="rgba(255,255,255,0.35)" />
        {streaks}
      </svg>
    </AbsoluteFill>
  );
};
