import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {BEATS} from './data/beats';
import {BedroomScene} from './components/BedroomScene';
import {NewsScene} from './components/NewsScene';
import {PalaceScene} from './components/PalaceScene';
import {PresidentOffice} from './components/PresidentOffice';
import {EconomicCrisisScene} from './components/EconomicCrisisScene';
import {FuelPolicyScene} from './components/FuelPolicyScene';
import {DecisionScene} from './components/DecisionScene';
import {SplitScreen} from './components/SplitScreen';
import {CommentScene} from './components/CommentScene';
import {Subtitle} from './components/Subtitle';
import {SoundEffects} from './components/SoundEffects';
import {Transition} from './components/Common';

type Kind = 'flash' | 'dark' | 'whip' | 'none';
const SCENES: {C: React.FC<{dur: number}>; t: Kind}[] = [
  {C: BedroomScene, t: 'none'},
  {C: NewsScene, t: 'dark'},
  {C: PalaceScene, t: 'flash'},
  {C: PresidentOffice, t: 'whip'},
  {C: EconomicCrisisScene, t: 'whip'},
  {C: FuelPolicyScene, t: 'dark'},
  {C: DecisionScene, t: 'dark'},
  {C: SplitScreen, t: 'flash'},
  {C: CommentScene, t: 'flash'},
];

// Tidak ada header: seluruh layar dipakai untuk cerita.
export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {/* Narasi = sumber timing utama. Ganti public/narasi.mp3 dengan rekaman asli. */}
    <Audio src={staticFile('narasi.mp3')} />
    {BEATS.map((b, i) => {
      const {C, t} = SCENES[i];
      return (
        <Sequence key={b.id} from={b.from} durationInFrames={b.dur} name={`Beat ${b.id} - ${b.name}`}>
          <C dur={b.dur} />
          <Transition kind={t} />
        </Sequence>
      );
    })}
    <SoundEffects />
    <Subtitle />
  </AbsoluteFill>
);
