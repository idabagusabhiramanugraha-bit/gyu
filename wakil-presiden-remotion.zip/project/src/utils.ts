import {Easing, interpolate, spring} from 'remotion';

export const lerp = (f: number, [a, b]: [number, number], [x, y]: [number, number], smooth = true) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: smooth ? Easing.bezier(0.22, 1, 0.36, 1) : undefined,
  });

// Spring "pop" dengan overshoot; deterministik.
export const pop = (f: number, start: number, fps: number, damping = 9) =>
  spring({frame: Math.max(0, f - start), fps, config: {damping, stiffness: 170, mass: 0.7}});

// Camera shake yang meluruh.
export const shake = (f: number, start: number, dur: number, amp: number) => {
  const t = f - start;
  if (t < 0 || t > dur) return {x: 0, y: 0, r: 0};
  const d = 1 - t / dur;
  return {x: Math.sin(f * 2.7) * amp * d, y: Math.cos(f * 3.3) * amp * d, r: Math.sin(f * 1.9) * amp * 0.04 * d};
};

export const pulse = (f: number, period: number) => Math.pow(Math.max(0, Math.sin((f / period) * Math.PI * 2)), 3);
