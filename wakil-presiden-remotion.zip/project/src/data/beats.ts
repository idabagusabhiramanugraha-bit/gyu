import {AUDIO_OFFSET, DURATION, FPS} from './config';

// Batas beat (detik) diturunkan dari timestamp SRT (kata per kata proporsional).
// TIMING SEMENTARA: final menunggu narasi.mp3 asli.
const STARTS = [0, 5.14, 10.56, 15.9, 20.16, 27.6, 38.2, 45.75, 50.0];
export const BEAT_NAMES = [
  'Terbangun', 'Berita pengangkatan', 'Memasuki Istana', 'Dipanggil Presiden', 'Krisis Indonesia',
  'Kebijakan Presiden', 'Dilema', 'Dua pilihan', 'Penonton menentukan',
];

const frames = STARTS.map((s, i) => (i === 0 ? 0 : Math.round((s + AUDIO_OFFSET) * FPS)));
export const BEATS = frames.map((from, i) => {
  const to = i === frames.length - 1 ? DURATION : frames[i + 1];
  return {id: i + 1, name: BEAT_NAMES[i], from, dur: to - from};
});
