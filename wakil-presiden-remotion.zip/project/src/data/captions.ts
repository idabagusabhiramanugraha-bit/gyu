// Dihasilkan dari captions.srt (patokan utama).
import {AUDIO_OFFSET, FPS} from './config';

export interface CaptionBlock {index: number; start: number; end: number; text: string}
export interface Word {text: string; start: number; end: number} // dalam frame
export interface Page {start: number; end: number; lines: Word[][]}

export const CAPTIONS: CaptionBlock[] = [
  {"index": 1, "start": 0.1, "end": 5.14, "text": "Bayangkan, pagi ini kamu bangun dan mendapati namamu terpampang di seluruh"},
  {"index": 2, "start": 5.14, "end": 9.98, "text": "berita nasional. Kamu resmi menggantikan Gibran sebagai Wakil Presiden Indonesia."},
  {"index": 3, "start": 10.56, "end": 15.9, "text": "Awalnya kamu mengira ini mimpi, tapi beberapa jam kemudian kamu sudah duduk di"},
  {"index": 4, "start": 15.9, "end": 19.56, "text": "istana menghadapi presiden yang langsung memberimu tugas pertama."},
  {"index": 5, "start": 20.16, "end": 25.0, "text": "Indonesia sedang menghadapi masalah besar. Harga kebutuhan pokok melonjak, rakyat"},
  {"index": 6, "start": 25.0, "end": 29.92, "text": "mulai resah, dan demonstrasi semakin ramai. Presiden menatapmu lalu berkata,"},
  {"index": 7, "start": 29.92, "end": 35.66, "text": "\"Saya punya solusi. Mulai besok, seluruh subsidi BBM akan dihapus agar anggaran"},
  {"index": 8, "start": 35.66, "end": 40.9, "text": "negara bisa dialihkan untuk pembangunan.\" Namun, keputusan ini bisa membuat harga"},
  {"index": 9, "start": 40.9, "end": 46.44, "text": "kebutuhan semakin mahal. Sekarang, Presiden meminta jawabanmu. A. Terima"},
  {"index": 10, "start": 46.44, "end": 52.1, "text": "kebijakan presiden. B. Tolak kebijakan presiden. Tulis A atau B di komentar."},
  {"index": 11, "start": 52.1, "end": 56.7, "text": "Pilihan mayoritas akan menentukan jalannya cerita dan nasib nusantara ada di"},
  {"index": 12, "start": 56.7, "end": 57.12, "text": "tanganmu."}
];

// Timestamp (detik) -> frame. AUDIO_OFFSET menggeser seluruh sinkronisasi.
export const sec2frame = (t: number) => Math.round((t + AUDIO_OFFSET) * FPS);

const MAX_CHARS = 24; // karakter per baris
const MAX_LINES = 2;

// SRT hanya punya timestamp per blok, jadi waktu tiap kata dibagi proporsional jumlah karakter.
export const buildWords = (b: CaptionBlock): Word[] => {
  const words = b.text.split(/\s+/).filter(Boolean);
  const total = words.reduce((s, w) => s + w.length + 1, 0);
  const s0 = sec2frame(b.start);
  const e0 = sec2frame(b.end);
  let acc = 0;
  return words.map((w) => {
    const start = s0 + Math.round(((e0 - s0) * acc) / total);
    acc += w.length + 1;
    const end = s0 + Math.round(((e0 - s0) * acc) / total);
    return {text: w, start, end};
  });
};

// Kata dikelompokkan jadi halaman maksimal 2 baris: narasi tidak tampil sekaligus.
export const buildPages = (): Page[] => {
  const pages: Page[] = [];
  for (const b of CAPTIONS) {
    let lines: Word[][] = [[]];
    const flush = () => {
      const all = lines.flat();
      if (all.length) pages.push({start: all[0].start, end: all[all.length - 1].end, lines});
      lines = [[]];
    };
    for (const w of buildWords(b)) {
      let cur = lines[lines.length - 1];
      const len = cur.map((x) => x.text).join(' ').length + (cur.length ? 1 : 0) + w.text.length;
      if (cur.length && len > MAX_CHARS) {
        if (lines.length >= MAX_LINES) {
          flush();
        } else {
          lines.push([]);
        }
        cur = lines[lines.length - 1];
      }
      cur.push(w);
    }
    flush();
  }
  return pages.map((p, i) => {
    const next = pages[i + 1];
    const end = next && next.start - p.end < 9 ? next.start : p.end + 4;
    return {...p, end};
  });
};

export const PAGES: Page[] = buildPages();

export const KEYWORDS = new Set([
  'gibran', 'wakil', 'presiden', 'bbm', 'subsidi', 'dihapus', 'mahal', 'demonstrasi', 'a', 'b',
  'komentar', 'terima', 'tolak', 'istana', 'nasib', 'nusantara', 'tanganmu', 'harga', 'mimpi',
]);
