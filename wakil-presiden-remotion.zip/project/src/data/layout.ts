// Koordinat (kanvas 1080x1920, titik kiri-atas) sesuai tabel Fase 1.
export interface Box {x: number; y: number; w: number; h: number}
export const SAFE = {subtitleY: 1330, subtitleH: 200, marginX: 60, rightUi: 120};
export const LAYOUT: Record<string, Box> = {
  subtitle: {x: 60, y: 1330, w: 900, h: 200},
  tv: {x: 60, y: 240, w: 960, h: 860},
  banner: {x: 110, y: 790, w: 860, h: 220},
  palace: {x: 0, y: 300, w: 1080, h: 720},
  fuelBubble: {x: 90, y: 200, w: 900, h: 340},
  pump: {x: 90, y: 600, w: 400, h: 560},
  choiceA: {x: 0, y: 180, w: 600, h: 1100},
  choiceB: {x: 480, y: 180, w: 600, h: 1100},
  commentUi: {x: 100, y: 200, w: 880, h: 400},
};
