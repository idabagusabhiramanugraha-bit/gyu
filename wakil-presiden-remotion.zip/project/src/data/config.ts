export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Geser sinkronisasi (detik) jika narasi.mp3 asli dimulai lebih lambat/cepat dari timestamp SRT.
// Positif = subtitle & adegan lebih lambat. SATU-SATUNYA tempat mengubah offset audio.
export const AUDIO_OFFSET = 0;

// Durasi mengikuti SRT (blok terakhir selesai 57,12 dtk) + ekor freeze frame.
export const DURATION_SEC = 58;
export const DURATION = Math.round(DURATION_SEC * FPS); // 1740 frame
