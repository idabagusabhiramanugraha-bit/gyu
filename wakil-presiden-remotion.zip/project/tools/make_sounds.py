"""Membuat SFX & musik sintetis (placeholder) ke public/sounds/*.wav. Bisa diganti file sendiri dengan nama sama."""
import wave, os
import numpy as np

SR = 44100
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'sounds')
os.makedirs(OUT, exist_ok=True)

def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.01, d=0.3):
    e = np.ones(n); na = max(1, int(a * SR)); e[:na] = np.linspace(0, 1, na)
    e *= np.exp(-np.arange(n) / (d * SR)); return e
def lp(x, k):  # lowpass sederhana (moving average)
    k = max(1, int(k)); return np.convolve(x, np.ones(k) / k, mode='same')
def hp(x, k): return x - lp(x, k)
def noise(d): return rng.standard_normal(int(SR * d))
def sine(f, d): return np.sin(2 * np.pi * np.cumsum(np.broadcast_to(f, (int(SR * d),)) if np.isscalar(f) else f) / SR)
def saw(f, d): x = (np.cumsum(np.full(int(SR * d), f)) / SR) % 1; return 2 * x - 1
def save(name, x, gain=0.8):
    x = np.asarray(x, dtype=float); m = np.max(np.abs(x)) or 1; x = x / m * gain
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())
def place(buf, x, at):
    i = int(at * SR); buf[i:i + len(x)] += x[:len(buf) - i]; return buf

def ding(f, d=0.5): return sine(f, d) * env(int(SR * d), 0.005, 0.15)
save('notification', np.concatenate([ding(880, .25), ding(1320, .5)]))
def pop(f0=700, f1=180, d=0.14):
    f = np.linspace(f0, f1, int(SR * d)); return sine(f, d) * env(len(f), 0.002, 0.05)
save('pop', pop()); save('comment_pop', pop(900, 300, .12))
save('notification_pop', np.concatenate([pop(800, 300, .1), np.zeros(int(SR * .06)), pop(1100, 450, .12)]))
def impact(d=0.9, low=55):
    n = int(SR * d); f = np.linspace(low * 2.2, low, n)
    return sine(f, d) * env(n, 0.002, 0.25) + lp(noise(d), 40) * env(n, 0.001, 0.12) * 0.8
save('impact', impact()); save('impact_soft', impact(0.5, 80) * 0.5); save('final_impact', impact(1.8, 45))
def whoosh(d=0.7):
    n = int(SR * d); e = np.sin(np.linspace(0, np.pi, n)) ** 2
    return lp(noise(d), 18) * e + 0.4 * hp(noise(d), 60) * e * 0.3
save('whoosh', whoosh())
def stab(freqs, d):
    return sum(saw(f, d) for f in freqs) * env(int(SR * d), 0.03, d * 0.6)
save('news_sting', np.concatenate([stab([392, 494], .22), stab([523, 659], .22), stab([659, 784, 988], .7)]))
click = lambda: hp(noise(0.05), 30) * env(int(SR * 0.05), 0.001, 0.012)
b = np.zeros(int(SR * .3)); place(b, click(), 0); place(b, click() * .8, .09); save('shutter', b)
b = np.zeros(int(SR * 3.2))
for k in range(6): place(b, lp(noise(0.12), 25) * env(int(SR * .12), 0.003, 0.03), 0.1 + k * 0.5)
save('footsteps', b)
save('orch', (saw(131, 1.6) + saw(196, 1.6) + saw(262, 1.6) * .7) * np.sin(np.linspace(0, np.pi, int(SR * 1.6))) ** 1.5)
save('paper', hp(noise(0.5), 12) * np.sin(np.linspace(0, np.pi, int(SR * .5))) ** 2 * (0.5 + 0.5 * np.abs(sine(18, .5))))
mk = lp(noise(4), 14) * 0.7
for i in range(14): place(mk, sine(rng.uniform(500, 900), .08) * env(int(SR * .08), .005, .03) * .4, rng.uniform(0, 3.8))
save('market', mk)
save('crowd', lp(noise(4), 22) * (0.7 + 0.3 * sine(0.7, 4)))
n = int(SR * 4); f = np.linspace(70, 220, n)
save('tension', (sine(f, 4) + 0.5 * saw(f * 0.5, 4)) * np.linspace(0.1, 1, n) * (0.6 + 0.4 * sine(7, 4)))
b = np.concatenate([sine(1000, .12) * env(int(SR * .12), .002, .08), np.zeros(int(SR * .08)), sine(1000, .12) * env(int(SR * .12), .002, .08)]); save('alert', b)
n = int(SR * 5); save('suspense', (sine(55, 5) + 0.6 * sine(58.5, 5) + 0.3 * saw(110, 5) * 0.3) * np.minimum(1, np.linspace(0, 2, n)))
hb = np.zeros(int(SR * 5.2))
for k in range(6):
    s = k * 0.86; place(hb, sine(55, .18) * env(int(SR * .18), .003, .06), s); place(hb, sine(48, .2) * env(int(SR * .2), .003, .07) * .7, s + .22)
save('heartbeat', hb)

# musik 60 dtk: Am - F - C - G, makin intens
D = 60; M = np.zeros(int(SR * D)); chords = [(220, 261.6, 329.6), (174.6, 220, 261.6), (261.6, 329.6, 392), (196, 246.9, 293.7)]
for bar in range(D // 4 + 1):
    ch = chords[bar % 4]; s = bar * 4.0; d = min(4.2, D - s)
    if d <= 0: break
    pad = sum(saw(f, d) + saw(f * 1.004, d) for f in ch); pad = lp(pad, 18) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 0.6
    place(M, pad * (0.15 + 0.5 * s / D), s)
    for k in range(8): place(M, sine(ch[k % 3] * 2, .4) * env(int(SR * .4), .005, .15) * 0.25 * (s / D + .2), s + k * 0.5)
for k in range(int(D / 0.55)):
    place(M, sine(50, .2) * env(int(SR * .2), .003, .07) * (0.2 + 0.8 * min(1, k * 0.55 / D)), k * 0.55) if k * 0.55 > 14 else None
save('music', M, 0.6)

# narasi sementara: hening 58 dtk (GANTI dengan rekaman asli)
